/**
 * خادم تطوير للمنصة التجارية الإسلامية
 * Development Server for Al-Sahala Enterprise E-commerce Platform
 * 
 * هذا السكربت يقوم بتشغيل خادم HTTP لخدمة ملفات المنصة
 * مع دعم كامل لوحدات ES6 وملفات CSS
 * 
 * الاستخدام:
 *   node server.js
 * 
 * سيتم تشغيل الخادم على: http://localhost:3000
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

// إعدادات الخادم
const PORT = process.env.PORT || 3000;
const BASE_DIR = __dirname;

// أنواع MIME المدعومة
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.pdf': 'application/pdf'
};

// دالة لتحديد نوع الملف
function getMimeType(filePath) {
    const ext = path.extname(filePath).toLowerCase();
    return MIME_TYPES[ext] || 'application/octet-stream';
}

// دالة لمعالجة طلبات الملفات
function handleFileRequest(filePath, res) {
    fs.readFile(filePath, (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // الملف غير موجود
                res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(`
                    <!DOCTYPE html>
                    <html lang="ar" dir="rtl">
                    <head>
                        <meta charset="UTF-8">
                        <title>404 - الملف غير موجود</title>
                        <style>
                            body { font-family: Arial, sans-serif; background: #f5f5f5; 
                                   display: flex; align-items: center; justify-content: center;
                                   min-height: 100vh; margin: 0; }
                            .error-box { background: white; padding: 40px; border-radius: 12px;
                                         box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; }
                            h1 { color: #105652; margin-bottom: 20px; }
                            p { color: #666; margin-bottom: 20px; }
                            a { color: #D4AF37; text-decoration: none; }
                            a:hover { text-decoration: underline; }
                        </style>
                    </head>
                    <body>
                        <div class="error-box">
                            <h1>404 - الملف غير موجود</h1>
                            <p>الصفحة المطلوبة غير موجودة في الخادم.</p>
                            <p><a href="/">العودة للرئيسية</a></p>
                        </div>
                    </body>
                    </html>
                `);
            } else {
                // خطأ في الخادم
                res.writeHead(500);
                res.end('خطأ في الخادم');
            }
            return;
        }

        const mimeType = getMimeType(filePath);
        res.writeHead(200, { 
            'Content-Type': mimeType,
            'Access-Control-Allow-Origin': '*'
        });
        res.end(data);
    });
}

// إنشاء وتشغيل الخادم
const server = http.createServer((req, res) => {
    console.log(`[${new Date().toLocaleString()}] ${req.method} ${req.url}`);
    
    // إزالة الاستعلام من العنوان
    let urlPath = req.url.split('?')[0];
    
    // فك تشفير عنوان URL
    try {
        urlPath = decodeURIComponent(urlPath);
    } catch (e) {
        console.log('خطأ في فك تشفير URL');
    }
    
    // منع الوصول للملفات الحساسة
    const sensitiveFiles = ['.env', '.git', '.DS_Store', 'Thumbs.db'];
    const ext = path.extname(urlPath).toLowerCase();
    
    if (sensitiveFiles.includes(ext) || urlPath.includes('..')) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('403 - غير مصرح بالوصول');
        return;
    }
    
    // تحديد مسار الملف
    let filePath = path.join(BASE_DIR, urlPath === '/' ? 'index.html' : urlPath);
    
    // التحقق من وجود الملف
    fs.stat(filePath, (err, stats) => {
        if (err || !stats.isFile()) {
            // إذا كان المسار مجلد، البحث عن index.html
            if (!err && stats.isDirectory()) {
                filePath = path.join(filePath, 'index.html');
                fs.stat(filePath, (err2, stats2) => {
                    if (err2 || !stats2.isFile()) {
                        handleFileRequest(filePath, res);
                    } else {
                        handleFileRequest(filePath, res);
                    }
                });
            } else {
                handleFileRequest(filePath, res);
            }
        } else {
            handleFileRequest(filePath, res);
        }
    });
});

// طباعة رسالة الترحيب
console.log(`
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║      المنصة التجارية الإسلامية - خادم التطوير                     ║
║      Al-Sahala Enterprise - Development Server                   ║
║                                                                  ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║   🚀 تم تشغيل الخادم بنجاح!                                      ║
║                                                                  ║
║   📍 العنوان: http://localhost:${PORT}                            ║
║                                                                  ║
║   📁 الملفات في: ${BASE_DIR.substring(0, 50)}...                ║
║                                                                  ║
║   💡 نصائح:                                                      ║
║      • افتح المتصفح وانتقل إلى العنوان أعلاه                      ║
║      • اضغط Ctrl+C لإيقاف الخادم                                ║
║      • استخدم ES6 modules تحتاج خادم HTTP                       ║
║                                                                  ║
║   📄 الصفحات المتاحة:                                            ║
║      • http://localhost:${PORT}/index.html                       ║
║      • http://localhost:${PORT}/shop.html                        ║
║      • http://localhost:${PORT}/product.html                     ║
║      • http://localhost:${PORT}/checkout.html                    ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
`);

// بدء الاستماع للطلبات
server.listen(PORT, () => {
    console.log(`✅ الخادم يعمل الآن...\n`);
});

// معالجة إيقاف الخادم
process.on('SIGINT', () => {
    console.log('\n\n⛔ جاري إيقاف الخادم...');
    server.close(() => {
        console.log('✅ تم إيقاف الخادم بنجاح. وداعاً!');
        process.exit(0);
    });
});

process.on('SIGTERM', () => {
    console.log('\n⛔ تم إيقاف الخادم');
    process.exit(0);
});
