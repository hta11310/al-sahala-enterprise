/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  إدارة واجهة المستخدم - Al-Sahala Enterprise                        ║
 * ║  UI Manager - النوافذ المنبثقة، الإشعارات، القوائم الجانبية         ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const UIManager = {
    // ═══════════════════════════════════════════════════════════════════
    // التهيئة
    // ═══════════════════════════════════════════════════════════════════
    
    init() {
        this.setupMobileMenu();
        this.setupSidebar();
        this.setupModals();
        this.setupScrollEffects();
        this.setupFormValidation();
        this.setupImageLoading();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد القائمة المتنقلة
    // ═══════════════════════════════════════════════════════════════════
    
    setupMobileMenu() {
        const menuToggle = document.getElementById('mobile-menu-toggle');
        const mobileMenu = document.getElementById('mobile-menu');
        const menuOverlay = document.getElementById('menu-overlay');
        const menuClose = document.getElementById('menu-close');
        
        if (menuToggle && mobileMenu) {
            menuToggle.addEventListener('click', () => {
                this.openMobileMenu();
            });
        }
        
        if (menuClose && mobileMenu) {
            menuClose.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        }
        
        if (menuOverlay) {
            menuOverlay.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        }
        
        // إغلاق القائمة عند تغيير حجم النافذة
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                this.closeMobileMenu();
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // فتح القائمة المتنقلة
    // ═══════════════════════════════════════════════════════════════════
    
    openMobileMenu() {
        const mobileMenu = document.getElementById('mobile-menu');
        const menuOverlay = document.getElementById('menu-overlay');
        const body = document.body;
        
        if (mobileMenu) {
            mobileMenu.classList.add('active');
        }
        
        if (menuOverlay) {
            menuOverlay.classList.add('active');
        }
        
        body.classList.add('no-scroll');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إغلاق القائمة المتنقلة
    // ═══════════════════════════════════════════════════════════════════
    
    closeMobileMenu() {
        const mobileMenu = document.getElementById('mobile-menu');
        const menuOverlay = document.getElementById('menu-overlay');
        const body = document.body;
        
        if (mobileMenu) {
            mobileMenu.classList.remove('active');
        }
        
        if (menuOverlay) {
            menuOverlay.classList.remove('active');
        }
        
        body.classList.remove('no-scroll');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد الشريط الجانبي
    // ═══════════════════════════════════════════════════════════════════
    
    setupSidebar() {
        // سلة التسوق
        const cartToggle = document.getElementById('cart-toggle');
        const cartSidebar = document.getElementById('cart-sidebar');
        const cartClose = document.getElementById('cart-close');
        const cartOverlay = document.getElementById('cart-overlay');
        
        if (cartToggle && cartSidebar) {
            cartToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.openSidebar(cartSidebar, 'cart');
            });
        }
        
        if (cartClose && cartSidebar) {
            cartClose.addEventListener('click', () => {
                this.closeSidebar(cartSidebar, 'cart');
            });
        }
        
        if (cartOverlay) {
            cartOverlay.addEventListener('click', () => {
                this.closeSidebar(cartSidebar, 'cart');
            });
        }
        
        // القائمة
        const navToggle = document.getElementById('nav-toggle');
        const navSidebar = document.getElementById('nav-sidebar');
        const navClose = document.getElementById('nav-close');
        
        if (navToggle && navSidebar) {
            navToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.openSidebar(navSidebar, 'nav');
            });
        }
        
        if (navClose && navSidebar) {
            navClose.addEventListener('click', () => {
                this.closeSidebar(navSidebar, 'nav');
            });
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // فتح الشريط الجانبي
    // ═══════════════════════════════════════════════════════════════════
    
    openSidebar(sidebar, type) {
        if (!sidebar) return;
        
        const overlay = document.getElementById(`${type}-overlay`);
        const body = document.body;
        
        sidebar.classList.add('active');
        if (overlay) {
            overlay.classList.add('active');
        }
        body.classList.add('no-scroll');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إغلاق الشريط الجانبي
    // ═══════════════════════════════════════════════════════════════════
    
    closeSidebar(sidebar, type) {
        if (!sidebar) return;
        
        const overlay = document.getElementById(`${type}-overlay`);
        const body = document.body;
        
        sidebar.classList.remove('active');
        if (overlay) {
            overlay.classList.remove('active');
        }
        body.classList.remove('no-scroll');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد النوافذ المنبثقة
    // ═══════════════════════════════════════════════════════════════════
    
    setupModals() {
        // إغلاق النافذة المنبثقة عند النقر خارجها
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-backdrop')) {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal);
                }
            }
        });
        
        // إغلاق النافذة المنبثقة عند الضغط على Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const activeModal = document.querySelector('.modal.active');
                if (activeModal) {
                    this.closeModal(activeModal);
                }
            }
        });
        
        // أزرار إغلاق النوافذ المنبثقة
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-modal-close]')) {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal);
                }
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // فتح نافذة منبثقة
    // ═══════════════════════════════════════════════════════════════════
    
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        const backdrop = document.getElementById(`${modalId}-backdrop`);
        const body = document.body;
        
        if (modal) {
            modal.classList.add('active');
            if (backdrop) {
                backdrop.classList.add('active');
            }
            body.classList.add('no-scroll');
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إغلاق نافذة منبثقة
    // ═══════════════════════════════════════════════════════════════════
    
    closeModal(modal) {
        if (!modal) return;
        
        const backdrop = modal.querySelector('.modal-backdrop');
        const body = document.body;
        
        modal.classList.remove('active');
        if (backdrop) {
            backdrop.classList.remove('active');
        }
        body.classList.remove('no-scroll');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض نافذة المنتج السريع
    // ═══════════════════════════════════════════════════════════════════
    
    showQuickView(product) {
        const modal = document.getElementById('quick-view-modal');
        if (!modal || !product) return;
        
        const content = modal.querySelector('.quick-view-content');
        const price = product.salePrice || product.price;
        
        content.innerHTML = `
            <div class="quick-view-gallery">
                <img src="${product.images?.[0] || product.thumbnail}" 
                     alt="${product.name}" 
                     class="quick-view-main-image"
                     onerror="this.src='${CONFIG.IMAGES.PLACEHOLDER}'">
            </div>
            <div class="quick-view-details">
                <span class="quick-view-category">${I18N.t(`category.${product.category}`)}</span>
                <h2 class="quick-view-title">${product.name}</h2>
                
                <div class="product-card-rating">
                    <div class="stars">
                        ${ProductManager.getStarsHtml(product.rating)}
                    </div>
                    <span class="rating-count">(${product.reviews} ${I18N.t('product.reviews')})</span>
                </div>
                
                <div class="quick-view-price">
                    <span class="quick-view-price-current">${CartManager.formatPrice(price)}</span>
                    ${product.salePrice ? `<span class="quick-view-price-original">${CartManager.formatPrice(product.price)}</span>` : ''}
                </div>
                
                <p class="quick-view-description">${product.description}</p>
                
                ${product.variants && product.variants.colors ? `
                    <div class="quick-view-options">
                        <h4>${I18N.t('product.select_color')}</h4>
                        <div class="product-card-variants">
                            ${product.variants.colors.map(color => `
                                <span class="variant-swatch active" style="background-color: ${color}" title="${I18N.t(`product.colors.${color}`)}"></span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                ${product.variants && product.variants.sizes ? `
                    <div class="quick-view-options">
                        <h4>${I18N.t('product.select_size')}</h4>
                        <div class="size-options">
                            ${product.variants.sizes.map(size => `
                                <button class="size-option">${size}</button>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                <div class="quick-view-options">
                    <h4>${I18N.t('product.quantity')}</h4>
                    <div class="quantity-input">
                        <button class="quantity-btn" onclick="updateQuickViewQuantity(-1)">-</button>
                        <input type="number" class="quantity-value" id="quick-view-quantity" value="1" min="1" max="${product.stock}">
                        <button class="quantity-btn" onclick="updateQuickViewQuantity(1)">+</button>
                    </div>
                </div>
                
                <div class="quick-view-actions">
                    <button class="btn btn-primary btn-lg" onclick="handleAddToCart(${product.id})">
                        ${I18N.t('product.add_to_cart')}
                    </button>
                    <button class="btn btn-outline btn-lg" onclick="handleWishlist(${product.id})">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;
        
        this.openModal('quick-view-modal');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد تأثيرات التمرير
    // ═══════════════════════════════════════════════════════════════════
    
    setupScrollEffects() {
        const header = document.querySelector('.header');
        
        if (!header) return;
        
        let lastScroll = 0;
        
        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset;
            
            // تأثير الرأس عند التمرير
            if (currentScroll > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
            
            lastScroll = currentScroll;
        }, { passive: true });
        
        // عرض عناصر عند التمرير
        this.setupScrollReveal();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد ظهور العناصر عند التمرير
    // ═══════════════════════════════════════════════════════════════════
    
    setupScrollReveal() {
        const revealElements = document.querySelectorAll('[data-reveal]');
        
        if (!revealElements.length) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        revealElements.forEach(el => observer.observe(el));
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد التحقق من النماذج
    // ═══════════════════════════════════════════════════════════════════
    
    setupFormValidation() {
        document.addEventListener('submit', (e) => {
            if (e.target.matches('[data-validate]')) {
                e.preventDefault();
                this.validateForm(e.target);
            }
        });
        
        // التحقق في الوقت الفعلي
        document.addEventListener('blur', (e) => {
            if (e.target.matches('[data-validate] input, [data-validate] select')) {
                this.validateField(e.target);
            }
        }, true);
        
        // إزالة رسائل الخطأ عند التعديل
        document.addEventListener('input', (e) => {
            if (e.target.matches('[data-validate] input, [data-validate] select')) {
                const errorEl = e.target.parentElement.querySelector('.form-error');
                if (errorEl) {
                    errorEl.remove();
                    e.target.classList.remove('error');
                }
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // التحقق من نموذج
    // ═══════════════════════════════════════════════════════════════════
    
    validateForm(form) {
        const inputs = form.querySelectorAll('input, select, textarea');
        let isValid = true;
        
        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });
        
        if (isValid) {
            const submitBtn = form.querySelector('[type="submit"]');
            if (submitBtn) {
                submitBtn.classList.add('loading');
                submitBtn.disabled = true;
                
                // محاكاة إرسال النموذج
                setTimeout(() => {
                    submitBtn.classList.remove('loading');
                    submitBtn.disabled = false;
                    this.showToast('تم إرسال النموذج بنجاح', 'success');
                }, 1500);
            }
        }
        
        return isValid;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // التحقق من حقل واحد
    // ═══════════════════════════════════════════════════════════════════
    
    validateField(input) {
        const value = input.value.trim();
        const type = input.type;
        const required = input.hasAttribute('required');
        const parent = input.parentElement;
        
        // إزالة رسالة الخطأ السابقة
        const existingError = parent.querySelector('.form-error');
        if (existingError) {
            existingError.remove();
        }
        input.classList.remove('error');
        
        // التحقق من الحقل المطلوب
        if (required && !value) {
            this.showFieldError(input, I18N.t('form.required'));
            return false;
        }
        
        // التحقق من البريد الإلكتروني
        if (type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                this.showFieldError(input, I18N.t('form.invalid_email'));
                return false;
            }
        }
        
        // التحقق من رقم الهاتف
        if (type === 'tel' && value) {
            const phoneRegex = /^[\d\s\-\+\(\)]{9,}$/;
            if (!phoneRegex.test(value)) {
                this.showFieldError(input, I18N.t('form.invalid_phone'));
                return false;
            }
        }
        
        // التحقق من كلمة المرور
        if (type === 'password' && value) {
            if (value.length < 8) {
                this.showFieldError(input, 'كلمة المرور يجب أن تكون 8 أحرف على الأقل');
                return false;
            }
        }
        
        // التحقق من تطابق كلمات المرور
        const confirmPassword = input.form?.querySelector('[name="confirm_password"]');
        if (input.name === 'password' && confirmPassword && value !== confirmPassword.value) {
            this.showFieldError(confirmPassword, I18N.t('form.password_mismatch'));
            return false;
        }
        
        return true;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض خطأ الحقل
    // ═══════════════════════════════════════════════════════════════════
    
    showFieldError(input, message) {
        input.classList.add('error');
        
        const error = document.createElement('div');
        error.className = 'form-error';
        error.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>${message}</span>
        `;
        
        input.parentElement.appendChild(error);
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد تحميل الصور
    // ═══════════════════════════════════════════════════════════════════
    
    setupImageLoading() {
        const images = document.querySelectorAll('img[loading="lazy"]');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                        }
                        img.classList.add('loaded');
                        observer.unobserve(img);
                    }
                });
            }, {
                rootMargin: '50px 0px'
            });
            
            images.forEach(img => {
                if (img.dataset.src) {
                    imageObserver.observe(img);
                }
            });
        } else {
            // تحميل فوري للمتصفحات القديمة
            images.forEach(img => {
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                }
            });
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض الإشعارات
    // ═══════════════════════════════════════════════════════════════════
    
    showToast(message, type = 'info', duration = CONFIG.TOAST_DURATION.DEFAULT) {
        const container = document.getElementById('toast-container');
        if (!container) return;
        
        const toastId = 'toast-' + Date.now();
        const icons = {
            success: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
            error: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
            warning: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
            info: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
        };
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.id = toastId;
        toast.innerHTML = `
            <span class="toast-icon">${icons[type] || icons.info}</span>
            <div class="toast-content">
                <span class="toast-message">${message}</span>
            </div>
            <button class="toast-close" onclick="UIManager.closeToast('${toastId}')">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        `;
        
        container.appendChild(toast);
        
        // حذف الإشعار تلقائياً
        setTimeout(() => {
            this.closeToast(toastId);
        }, duration);
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إغلاق الإشعار
    // ═══════════════════════════════════════════════════════════════════
    
    closeToast(toastId) {
        const toast = document.getElementById(toastId);
        if (toast) {
            toast.style.animation = 'toast-slide-out 0.3s ease forwards';
            setTimeout(() => {
                toast.remove();
            }, 300);
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض مؤشر التحميل
    // ═══════════════════════════════════════════════════════════════════
    
    showLoader(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = `
            <div class="loader-container">
                <div class="loader"></div>
            </div>
        `;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إخفاء مؤشر التحميل
    // ═══════════════════════════════════════════════════════════════════
    
    hideLoader(containerId) {
        const container = document.getElementById(containerId);
        const loader = container?.querySelector('.loader-container');
        if (loader) {
            loader.remove();
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض عنصر فارغ
    // ═══════════════════════════════════════════════════════════════════
    
    showEmptyState(containerId, icon, title, message, actionText, actionUrl) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">${icon}</div>
                <h3 class="empty-state-title">${title}</h3>
                <p class="empty-state-message">${message}</p>
                ${actionText && actionUrl ? `
                    <a href="${actionUrl}" class="btn btn-primary">${actionText}</a>
                ` : ''}
            </div>
        `;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض تفاصيل المنتج
    // ═══════════════════════════════════════════════════════════════════
    
    showProductDetails(productId) {
        window.location.href = `product.html?id=${productId}`;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إضافة تنسيق العملة
    // ═══════════════════════════════════════════════════════════════════
    
    formatCurrency(amount, currency = I18N.currentCurrency) {
        const rate = I18N.currencyRates[currency] || 1;
        const converted = amount * rate;
        const symbol = I18N.currentCurrencyData?.symbol || 'ر.س';
        return `${symbol} ${I18N.formatNumber(converted.toFixed(2))}`;
    }
};

// ═══════════════════════════════════════════════════════════════════════
// دوال مساعدة
// ═══════════════════════════════════════════════════════════════════════

function updateQuickViewQuantity(change) {
    const input = document.getElementById('quick-view-quantity');
    if (!input) return;
    
    const currentValue = parseInt(input.value) || 1;
    const newValue = currentValue + change;
    const max = parseInt(input.max) || 99;
    
    if (newValue >= 1 && newValue <= max) {
        input.value = newValue;
    }
}

function openMobileMenu() {
    UIManager.openMobileMenu();
}

function closeMobileMenu() {
    UIManager.closeMobileMenu();
}

function openCartSidebar() {
    CartManager.updateCartSidebar();
    UIManager.openSidebar(document.getElementById('cart-sidebar'), 'cart');
}

function closeCartSidebar() {
    UIManager.closeSidebar(document.getElementById('cart-sidebar'), 'cart');
}

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    UIManager.init();
});

// تصدير الوحدة
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIManager;
}
