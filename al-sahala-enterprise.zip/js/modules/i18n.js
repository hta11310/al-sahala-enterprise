/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  نظام الترجمة واللغات - Al-Sahala Enterprise                         ║
 * ║  Internationalization System - التبديل بين اللغات والعملات          ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const I18N = {
    // ═══════════════════════════════════════════════════════════════════
    // الترجمات
    // ═══════════════════════════════════════════════════════════════════
    
    translations: {
        ar: {
            // ═══════════════════════════════════════════════════════════
            // الترويسة العامة
            // ═══════════════════════════════════════════════════════════
            'app.name': 'منصة ومتجر السهالة',
            'app.tagline': 'تسوق بسهولة وأمان',
            'app.description': 'أفضل منصة تسوق إلكتروني في المنطقة',
            
            // ═══════════════════════════════════════════════════════════
            // التنقل
            // ═══════════════════════════════════════════════════════════
            'nav.home': 'الرئيسية',
            'nav.shop': 'المتجر',
            'nav.categories': 'الفئات',
            'nav.deals': 'العروض',
            'nav.new_arrivals': 'وصل حديثاً',
            'nav.best_sellers': 'الأكثر مبيعاً',
            'nav.contact': 'اتصل بنا',
            'nav.about': 'من نحن',
            
            // ═══════════════════════════════════════════════════════════
            // المستخدم
            // ═══════════════════════════════════════════════════════════
            'user.login': 'تسجيل الدخول',
            'user.register': 'إنشاء حساب',
            'user.logout': 'تسجيل خروج',
            'user.profile': 'حسابي',
            'user.orders': 'طلباتي',
            'user.wishlist': 'قائمة الأمنيات',
            'user.settings': 'الإعدادات',
            'user.welcome': 'مرحباً، {name}',
            'user.guest': 'زائر',
            
            // ═══════════════════════════════════════════════════════════
            // اللغة والعملة
            // ═══════════════════════════════════════════════════════════
            'language': 'اللغة',
            'language.arabic': 'العربية',
            'language.english': 'الإنجليزية',
            'currency': 'العملة',
            'currency.sar': 'ريال سعودي',
            'currency.aed': 'درهم إماراتي',
            'currency.usd': 'دولار أمريكي',
            'currency.egp': 'جنيه مصري',
            'direction.rtl': 'rtl',
            'direction.ltr': 'ltr',
            
            // ═══════════════════════════════════════════════════════════
            // سلة التسوق
            // ═══════════════════════════════════════════════════════════
            'cart.title': 'سلة التسوق',
            'cart.empty': 'سلة التسوق فارغة',
            'cart.empty_message': 'لم تقم بإضافة أي منتجات بعد',
            'cart.add': 'أضف منتجات لتسوقك',
            'cart.total': 'المجموع',
            'cart.subtotal': 'المجموع الفرعي',
            'cart.shipping': 'تكلفة الشحن',
            'cart.tax': 'الضريبة',
            'cart.discount': 'الخصم',
            'cart.free': 'مجاني',
            'cart.checkout': 'إتمام الشراء',
            'cart.continue': 'متابعة التسوق',
            'cart.remove': 'إزالة',
            'cart.items': '{count} منتجات',
            'cart.item': 'منتج واحد',
            'cart.added_success': 'تمت إضافة المنتج إلى السلة',
            'cart.removed_success': 'تم إزالة المنتج من السلة',
            'cart.update_success': 'تم تحديث السلة',
            
            // ═══════════════════════════════════════════════════════════
            // قائمة الأمنيات
            // ═══════════════════════════════════════════════════════════
            'wishlist.title': 'قائمة الأمنيات',
            'wishlist.empty': 'قائمة الأمنيات فارغة',
            'wishlist.add': 'أضف منتجات لقائمة أمنياتك',
            'wishlist.move_to_cart': 'نقل إلى السلة',
            'wishlist.added_success': 'تمت إضافة المنتج لقائمة الأمنيات',
            'wishlist.removed_success': 'تم إزالة المنتج من قائمة الأمنيات',
            
            // ═══════════════════════════════════════════════════════════
            // المنتجات
            // ═══════════════════════════════════════════════════════════
            'product.add_to_cart': 'إضافة للسلة',
            'product.buy_now': 'شراء الآن',
            'product.details': 'تفاصيل المنتج',
            'product.description': 'الوصف',
            'product.specifications': 'المواصفات',
            'product.reviews': 'المراجعات',
            'product.related': 'منتجات مشابهة',
            'product.sku': 'رمز المنتج',
            'product.brand': 'الماركة',
            'product.category': 'الفئة',
            'product.available': 'متوفر',
            'product.out_of_stock': 'غير متوفر',
            'product.in_stock': 'المتبقي: {count}',
            'product.low_stock': 'كمية محدودة',
            'product.price': 'السعر',
            'product.old_price': 'السعر القديم',
            'product.discount': 'خصم',
            'product.new': 'جديد',
            'product.hot': '热门',
            'product.sale': 'sale',
            'product.select_size': 'اختر المقاس',
            'product.select_color': 'اختر اللون',
            'product.quantity': 'الكمية',
            'product.rating': 'التقييم',
            'product.ratings': 'تقييمات',
            'product.reviews_count': '{count} مراجعة',
            'product.write_review': 'اكتب مراجعة',
            'product.share': 'مشاركة',
            'product.compare': 'مقارنة',
            'product.sizes': ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
            'product.colors': {
                'black': 'أسود',
                'white': 'أبيض',
                'red': 'أحمر',
                'blue': 'أزرق',
                'green': 'أخضر',
                'yellow': 'أصفر',
                'pink': 'وردي',
                'purple': 'بنفسجي',
                'gray': 'رمادي',
                'brown': 'بني',
                'beige': 'بيج',
                'navy': 'كحلي',
                'orange': 'برتقالي'
            },
            
            // ═══════════════════════════════════════════════════════════
            // التصفية والبحث
            // ═══════════════════════════════════════════════════════════
            'search.placeholder': 'ابحث عن منتجات...',
            'search.button': 'بحث',
            'search.results': 'نتائج البحث',
            'search.no_results': 'لم يتم العثور على منتجات',
            'search.try_different': 'جرب كلمات مختلفة',
            'search.recent': 'عمليات البحث الأخيرة',
            'search.trending': 'عمليات البحث الشائعة',
            'filter.title': 'تصفية',
            'filter.category': 'الفئة',
            'filter.price': 'السعر',
            'filter.price_range': 'نطاق السعر',
            'filter.brand': 'الماركة',
            'filter.color': 'اللون',
            'filter.size': 'المقاس',
            'filter.rating': 'التقييم',
            'filter.clear': 'مسح الفلاتر',
            'filter.apply': 'تطبيق',
            'filter.sort': 'ترتيب',
            'filter.sort_newest': 'الأحدث',
            'filter.sort_price_low': 'السعر: من الأقل للأعلى',
            'filter.sort_price_high': 'السعر: من الأعلى للأقل',
            'filter.sort_popular': 'الأكثر شعبية',
            'filter.sort_rating': 'الأعلى تقييماً',
            
            // ═══════════════════════════════════════════════════════════
            // الفئات
            // ═══════════════════════════════════════════════════════════
            'category.all': 'الكل',
            'category.electronics': 'الإلكترونيات',
            'category.clothing': 'الأزياء',
            'category.beauty': 'الجمال',
            'category.home': 'المنزل والمطبخ',
            'category.sports': 'رياضة',
            'category.books': 'الكتب',
            'category.toys': 'الألعاب',
            'category.baby': 'الرضع',
            'category.food': 'المطاعم والأطعمة',
            'category.view_all': 'عرض الكل',
            
            // ═══════════════════════════════════════════════════════════
            // الدفع
            // ═══════════════════════════════════════════════════════════
            'checkout.title': 'إتمام الشراء',
            'checkout.guest': 'متابعة كزائر',
            'checkout.login': 'سجل دخولك أولاً',
            'checkout.shipping': 'معلومات الشحن',
            'checkout.payment': 'معلومات الدفع',
            'checkout.review': 'مراجعة الطلب',
            'checkout.confirm': 'تأكيد الطلب',
            'checkout.shipping_method': 'طريقة الشحن',
            'checkout.payment_method': 'طريقة الدفع',
            'checkout.promo_code': 'كود الخصم',
            'checkout.apply': 'تطبيق',
            'checkout.order_summary': 'ملخص الطلب',
            'checkout.place_order': 'إتمام الطلب',
            'checkout.thank_you': 'شكراً لطلبك!',
            'checkout.order_number': 'رقم الطلب: {number}',
            'checkout.order_confirmed': 'تم تأكيد طلبك بنجاح',
            'checkout.continue_shopping': 'متابعة التسوق',
            
            // ═══════════════════════════════════════════════════════════
            // النماذج
            // ═══════════════════════════════════════════════════════════
            'form.name': 'الاسم',
            'form.email': 'البريد الإلكتروني',
            'form.phone': 'رقم الهاتف',
            'form.password': 'كلمة المرور',
            'form.confirm_password': 'تأكيد كلمة المرور',
            'form.address': 'العنوان',
            'form.city': 'المدينة',
            'form.district': 'الحي',
            'form.zip_code': 'الرمز البريدي',
            'form.notes': 'ملاحظات',
            'form.required': 'هذا الحقل مطلوب',
            'form.invalid_email': 'بريد إلكتروني غير صالح',
            'form.invalid_phone': 'رقم هاتف غير صالح',
            'form.password_mismatch': 'كلمتا المرور غير متطابقتين',
            'form.password_weak': 'كلمة المرور ضعيفة',
            'form.register_success': 'تم إنشاء حسابك بنجاح',
            'form.login_success': 'تم تسجيل الدخول بنجاح',
            
            // ═══════════════════════════════════════════════════════════
            // الإشعارات
            // ═══════════════════════════════════════════════════════════
            'toast.success': 'نجاح',
            'toast.error': 'خطأ',
            'toast.warning': 'تحذير',
            'toast.info': 'معلومات',
            'toast.dismiss': 'إغلاق',
            
            // ═══════════════════════════════════════════════════════════
            // التذييل
            // ═══════════════════════════════════════════════════════════
            'footer.about': 'منصة ومتجر السهالة - تسوق بأفضل الأسعار',
            'footer.customer_service': 'خدمة العملاء',
            'footer.help': 'مركز المساعدة',
            'footer.returns': 'سياسة الإرجاع',
            'footer.privacy': 'سياسة الخصوصية',
            'footer.terms': 'الشروط والأحكام',
            'footer.contact': 'اتصل بنا',
            'footer.newsletter': 'النشرة البريدية',
            'footer.newsletter_text': 'اشترك لتصلك آخر العروض والمنتجات',
            'footer.subscribe': 'اشترك',
            'footer.email_placeholder': 'أدخل بريدك الإلكتروني',
            'footer.rights': 'جميع الحقوق محفوظة',
            'footer.made_with': 'صنع بـ',
            
            // ═══════════════════════════════════════════════════════════
            // الأوقات والأحداث
            // ═══════════════════════════════════════════════════════════
            'time.now': 'الآن',
            'time.minutes_ago': 'منذ {count} دقائق',
            'time.hours_ago': 'منذ {count} ساعات',
            'time.days_ago': 'منذ {count} أيام',
            'time.weeks_ago': 'منذ {count} أسابيع',
            'event.new_arrival': 'وصل حديثاً',
            'event.sale': 'خصم {percent}%',
            'event.hot_deal': 'صفقة ساخنة',
            'event.free_shipping': 'توصيل مجاني',
            
            // ═══════════════════════════════════════════════════════════
            // أيام الأسبوع
            // ═══════════════════════════════════════════════════════════
            'days.saturday': 'السبت',
            'days.sunday': 'الأحد',
            'days.monday': 'الاثنين',
            'days.tuesday': 'الثلاثاء',
            'days.wednesday': 'الأربعاء',
            'days.thursday': 'الخميس',
            'days.friday': 'الجمعة',
            
            // ═══════════════════════════════════════════════════════════
            // الأشهر
            // ═══════════════════════════════════════════════════════════
            'months.january': 'يناير',
            'months.february': 'فبراير',
            'months.march': 'مارس',
            'months.april': 'أبريل',
            'months.may': 'مايو',
            'months.june': 'يونيو',
            'months.july': 'يوليو',
            'months.august': 'أغسطس',
            'months.september': 'سبتمبر',
            'months.october': 'أكتوبر',
            'months.november': 'نوفمبر',
            'months.december': 'ديسمبر'
        },
        en: {
            'app.name': 'Al-Sahala Platform',
            'app.tagline': 'Shop with ease and safety',
            'app.description': 'The best e-commerce platform in the region',
            'nav.home': 'Home',
            'nav.shop': 'Shop',
            'nav.categories': 'Categories',
            'nav.deals': 'Deals',
            'nav.new_arrivals': 'New Arrivals',
            'nav.best_sellers': 'Best Sellers',
            'nav.contact': 'Contact Us',
            'nav.about': 'About Us',
            'user.login': 'Login',
            'user.register': 'Create Account',
            'user.logout': 'Logout',
            'user.profile': 'My Account',
            'user.orders': 'My Orders',
            'user.wishlist': 'Wishlist',
            'user.settings': 'Settings',
            'user.welcome': 'Welcome, {name}',
            'user.guest': 'Guest',
            'language': 'Language',
            'language.arabic': 'Arabic',
            'language.english': 'English',
            'currency': 'Currency',
            'currency.sar': 'Saudi Riyal',
            'currency.aed': 'UAE Dirham',
            'currency.usd': 'US Dollar',
            'currency.egp': 'Egyptian Pound',
            'direction.rtl': 'rtl',
            'direction.ltr': 'ltr',
            'cart.title': 'Shopping Cart',
            'cart.empty': 'Your cart is empty',
            'cart.empty_message': 'You haven\'t added any products yet',
            'cart.add': 'Add products to your cart',
            'cart.total': 'Total',
            'cart.subtotal': 'Subtotal',
            'cart.shipping': 'Shipping',
            'cart.tax': 'Tax',
            'cart.discount': 'Discount',
            'cart.free': 'Free',
            'cart.checkout': 'Checkout',
            'cart.continue': 'Continue Shopping',
            'cart.remove': 'Remove',
            'cart.items': '{count} items',
            'cart.item': '1 item',
            'cart.added_success': 'Product added to cart',
            'cart.removed_success': 'Product removed from cart',
            'cart.update_success': 'Cart updated',
            'wishlist.title': 'Wishlist',
            'wishlist.empty': 'Your wishlist is empty',
            'wishlist.add': 'Add products to your wishlist',
            'wishlist.move_to_cart': 'Move to Cart',
            'wishlist.added_success': 'Product added to wishlist',
            'wishlist.removed_success': 'Product removed from wishlist',
            'product.add_to_cart': 'Add to Cart',
            'product.buy_now': 'Buy Now',
            'product.details': 'Product Details',
            'product.description': 'Description',
            'product.specifications': 'Specifications',
            'product.reviews': 'Reviews',
            'product.related': 'Related Products',
            'product.sku': 'SKU',
            'product.brand': 'Brand',
            'product.category': 'Category',
            'product.available': 'Available',
            'product.out_of_stock': 'Out of Stock',
            'product.in_stock': 'In Stock: {count}',
            'product.low_stock': 'Limited Quantity',
            'product.price': 'Price',
            'product.old_price': 'Original Price',
            'product.discount': 'Discount',
            'product.new': 'New',
            'product.hot': 'Hot',
            'product.sale': 'Sale',
            'product.select_size': 'Select Size',
            'product.select_color': 'Select Color',
            'product.quantity': 'Quantity',
            'product.rating': 'Rating',
            'product.ratings': 'Ratings',
            'product.reviews_count': '{count} reviews',
            'product.write_review': 'Write a Review',
            'product.share': 'Share',
            'product.compare': 'Compare',
            'search.placeholder': 'Search for products...',
            'search.button': 'Search',
            'search.results': 'Search Results',
            'search.no_results': 'No products found',
            'search.try_different': 'Try different keywords',
            'search.recent': 'Recent Searches',
            'search.trending': 'Trending Searches',
            'filter.title': 'Filter',
            'filter.category': 'Category',
            'filter.price': 'Price',
            'filter.price_range': 'Price Range',
            'filter.brand': 'Brand',
            'filter.color': 'Color',
            'filter.size': 'Size',
            'filter.rating': 'Rating',
            'filter.clear': 'Clear Filters',
            'filter.apply': 'Apply',
            'filter.sort': 'Sort',
            'filter.sort_newest': 'Newest',
            'filter.sort_price_low': 'Price: Low to High',
            'filter.sort_price_high': 'Price: High to Low',
            'filter.sort_popular': 'Most Popular',
            'filter.sort_rating': 'Highest Rated',
            'category.all': 'All',
            'category.electronics': 'Electronics',
            'category.clothing': 'Clothing',
            'category.beauty': 'Beauty',
            'category.home': 'Home & Kitchen',
            'category.sports': 'Sports',
            'category.books': 'Books',
            'category.toys': 'Toys',
            'category.baby': 'Baby',
            'category.food': 'Food & Restaurants',
            'category.view_all': 'View All',
            'checkout.title': 'Checkout',
            'checkout.guest': 'Continue as Guest',
            'checkout.login': 'Please login first',
            'checkout.shipping': 'Shipping Information',
            'checkout.payment': 'Payment Information',
            'checkout.review': 'Order Review',
            'checkout.confirm': 'Confirm Order',
            'checkout.shipping_method': 'Shipping Method',
            'checkout.payment_method': 'Payment Method',
            'checkout.promo_code': 'Promo Code',
            'checkout.apply': 'Apply',
            'checkout.order_summary': 'Order Summary',
            'checkout.place_order': 'Place Order',
            'checkout.thank_you': 'Thank you for your order!',
            'checkout.order_number': 'Order Number: {number}',
            'checkout.order_confirmed': 'Your order has been confirmed',
            'checkout.continue_shopping': 'Continue Shopping',
            'form.name': 'Name',
            'form.email': 'Email',
            'form.phone': 'Phone Number',
            'form.password': 'Password',
            'form.confirm_password': 'Confirm Password',
            'form.address': 'Address',
            'form.city': 'City',
            'form.district': 'District',
            'form.zip_code': 'Zip Code',
            'form.notes': 'Notes',
            'form.required': 'This field is required',
            'form.invalid_email': 'Invalid email address',
            'form.invalid_phone': 'Invalid phone number',
            'form.password_mismatch': 'Passwords do not match',
            'form.password_weak': 'Password is too weak',
            'form.register_success': 'Your account has been created',
            'form.login_success': 'You have been logged in',
            'toast.success': 'Success',
            'toast.error': 'Error',
            'toast.warning': 'Warning',
            'toast.info': 'Information',
            'toast.dismiss': 'Dismiss',
            'footer.about': 'Al-Sahala Platform - Shop at the best prices',
            'footer.customer_service': 'Customer Service',
            'footer.help': 'Help Center',
            'footer.returns': 'Return Policy',
            'footer.privacy': 'Privacy Policy',
            'footer.terms': 'Terms & Conditions',
            'footer.contact': 'Contact Us',
            'footer.newsletter': 'Newsletter',
            'footer.newsletter_text': 'Subscribe to receive the latest offers and products',
            'footer.subscribe': 'Subscribe',
            'footer.email_placeholder': 'Enter your email',
            'footer.rights': 'All rights reserved',
            'footer.made_with': 'Made with',
            'time.now': 'Just now',
            'time.minutes_ago': '{count} minutes ago',
            'time.hours_ago': '{count} hours ago',
            'time.days_ago': '{count} days ago',
            'time.weeks_ago': '{count} weeks ago',
            'event.new_arrival': 'New Arrival',
            'event.sale': '{percent}% OFF',
            'event.hot_deal': 'Hot Deal',
            'event.free_shipping': 'Free Shipping',
            'days.saturday': 'Saturday',
            'days.sunday': 'Sunday',
            'days.monday': 'Monday',
            'days.tuesday': 'Tuesday',
            'days.wednesday': 'Wednesday',
            'days.thursday': 'Thursday',
            'days.friday': 'Friday',
            'months.january': 'January',
            'months.february': 'February',
            'months.march': 'March',
            'months.april': 'April',
            'months.may': 'May',
            'months.june': 'June',
            'months.july': 'July',
            'months.august': 'August',
            'months.september': 'September',
            'months.october': 'October',
            'months.november': 'November',
            'months.december': 'December'
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الإعدادات الحالية
    // ═══════════════════════════════════════════════════════════════════
    
    currentLanguage: CONFIG.DEFAULT_LANGUAGE,
    currentCurrency: CONFIG.DEFAULT_CURRENCY,
    currencyRates: {
        SAR: 1,
        AED: 0.98,
        USD: 3.75,
        EGP: 0.12,
        YER: 0.015,
        KWD: 12.2
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة النظام
    // ═══════════════════════════════════════════════════════════════════
    
    init() {
        this.loadSettings();
        this.applyLanguage();
        this.applyCurrency();
        this.setupLanguageSwitcher();
        this.setupCurrencySwitcher();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحميل الإعدادات
    // ═══════════════════════════════════════════════════════════════════
    
    loadSettings() {
        const savedLang = localStorage.getItem(CONFIG.STORAGE_KEYS.LANGUAGE);
        const savedCurrency = localStorage.getItem(CONFIG.STORAGE_KEYS.CURRENCY);
        
        if (savedLang && CONFIG.SUPPORTED_LANGUAGES.includes(savedLang)) {
            this.currentLanguage = savedLang;
        } else {
            this.detectBrowserLanguage();
        }
        
        if (savedCurrency) {
            this.currentCurrency = savedCurrency;
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // اكتشاف لغة المتصفح
    // ═══════════════════════════════════════════════════════════════════
    
    detectBrowserLanguage() {
        const browserLang = navigator.language || navigator.userLanguage;
        const langCode = browserLang.split('-')[0];
        
        if (CONFIG.SUPPORTED_LANGUAGES.includes(langCode)) {
            this.currentLanguage = langCode;
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تطبيق اللغة
    // ═══════════════════════════════════════════════════════════════════
    
    applyLanguage() {
        document.documentElement.lang = this.currentLanguage;
        document.documentElement.dir = CONFIG.RTL_LANGUAGES.includes(this.currentLanguage) ? 'rtl' : 'ltr';
        document.body.classList.add(this.currentLanguage === 'ar' ? 'rtl-text' : 'ltr-text');
        localStorage.setItem(CONFIG.STORAGE_KEYS.LANGUAGE, this.currentLanguage);
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تبديل اللغة
    // ═══════════════════════════════════════════════════════════════════
    
    setLanguage(lang) {
        if (!CONFIG.SUPPORTED_LANGUAGES.includes(lang)) return;
        
        this.currentLanguage = lang;
        this.applyLanguage();
        this.updateContent();
        this.updateLanguageSwitcher();
        
        // إعادة تحميل الصفحة لتطبيق التغييرات بالكامل
        window.location.reload();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد مفتاح اللغة
    // ═══════════════════════════════════════════════════════════════════
    
    setupLanguageSwitcher() {
        const switchers = document.querySelectorAll('[data-language-switcher]');
        switchers.forEach(switcher => {
            switcher.addEventListener('click', (e) => {
                e.preventDefault();
                const lang = switcher.dataset.lang;
                this.setLanguage(lang);
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث مفتاح اللغة
    // ═══════════════════════════════════════════════════════════════════
    
    updateLanguageSwitcher() {
        const switchers = document.querySelectorAll('[data-language-switcher]');
        switchers.forEach(switcher => {
            if (switcher.dataset.lang === this.currentLanguage) {
                switcher.classList.add('active');
            } else {
                switcher.classList.remove('active');
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تطبيق العملة
    // ═══════════════════════════════════════════════════════════════════
    
    applyCurrency() {
        const currency = CONFIG.SUPPORTED_CURRENCIES.find(c => c.code === this.currentCurrency);
        if (currency) {
            this.currentCurrencyData = currency;
            localStorage.setItem(CONFIG.STORAGE_KEYS.CURRENCY, this.currentCurrency);
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تبديل العملة
    // ═══════════════════════════════════════════════════════════════════
    
    setCurrency(currencyCode) {
        const currency = CONFIG.SUPPORTED_CURRENCIES.find(c => c.code === currencyCode);
        if (!currency) return;
        
        this.currentCurrency = currencyCode;
        this.currentCurrencyData = currency;
        this.applyCurrency();
        this.updateCurrencySwitcher();
        this.updatePrices();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد مفتاح العملة
    // ═══════════════════════════════════════════════════════════════════
    
    setupCurrencySwitcher() {
        const switchers = document.querySelectorAll('[data-currency-switcher]');
        switchers.forEach(switcher => {
            switcher.addEventListener('click', (e) => {
                e.preventDefault();
                const currency = switcher.dataset.currency;
                this.setCurrency(currency);
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث مفتاح العملة
    // ═══════════════════════════════════════════════════════════════════
    
    updateCurrencySwitcher() {
        const switchers = document.querySelectorAll('[data-currency-switcher]');
        switchers.forEach(switcher => {
            if (switcher.dataset.currency === this.currentCurrency) {
                switcher.classList.add('active');
            } else {
                switcher.classList.remove('active');
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث الأسعار
    // ═══════════════════════════════════════════════════════════════════
    
    updatePrices() {
        const priceElements = document.querySelectorAll('[data-price]');
        const rate = this.currencyRates[this.currentCurrency];
        const symbol = this.currentCurrencyData.symbol;
        
        priceElements.forEach(el => {
            const originalPrice = parseFloat(el.dataset.price);
            const convertedPrice = (originalPrice * rate).toFixed(2);
            el.textContent = `${symbol} ${this.formatNumber(convertedPrice)}`;
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تنسيق الأرقام
    // ═══════════════════════════════════════════════════════════════════
    
    formatNumber(num) {
        if (this.currentLanguage === 'ar') {
            // تحويل الأرقام للإنجليزية للعرض الصحيح
            return num.toString().replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
        }
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحويل العملة
    // ═══════════════════════════════════════════════════════════════════
    
    convertPrice(amount, fromCurrency = 'SAR') {
        const fromRate = this.currencyRates[fromCurrency] || 1;
        const toRate = this.currencyRates[this.currentCurrency] || 1;
        const rate = toRate / fromRate;
        return (amount * rate).toFixed(2);
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على نص الترجمة
    // ═══════════════════════════════════════════════════════════════════
    
    t(key, params = {}) {
        const translations = this.translations[this.currentLanguage] || this.translations[CONFIG.DEFAULT_LANGUAGE];
        let text = translations[key] || this.translations[CONFIG.DEFAULT_LANGUAGE][key] || key;
        
        // استبدال المعاملات
        if (params && Object.keys(params).length > 0) {
            Object.keys(params).forEach(param => {
                text = text.replace(new RegExp(`\\{${param}\\}`, 'g'), params[param]);
            });
        }
        
        return text;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث المحتوى
    // ═══════════════════════════════════════════════════════════════════
    
    updateContent() {
        const elements = document.querySelectorAll('[data-i18n]');
        elements.forEach(el => {
            const key = el.dataset.i18n;
            el.textContent = this.t(key);
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على اتجاه النص
    // ═══════════════════════════════════════════════════════════════════
    
    getDirection() {
        return CONFIG.RTL_LANGUAGES.includes(this.currentLanguage) ? 'rtl' : 'ltr';
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // التحقق من RTL
    // ═══════════════════════════════════════════════════════════════════
    
    isRTL() {
        return this.getDirection() === 'rtl';
    }
};

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    I18N.init();
});

// تصدير الوحدة
if (typeof module !== 'undefined' && module.exports) {
    module.exports = I18N;
}
