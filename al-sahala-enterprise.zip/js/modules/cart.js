/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  إدارة سلة التسوق - Al-Sahala Enterprise                             ║
 * ║  Shopping Cart Management - إضافة، إزالة، تحديث المنتجات           ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const CartManager = {
    // ═══════════════════════════════════════════════════════════════════
    // البيانات
    // ═══════════════════════════════════════════════════════════════════
    
    items: [],
    coupon: null,
    shippingMethod: null,
    
    // ═══════════════════════════════════════════════════════════════════
    // التهيئة
    // ═══════════════════════════════════════════════════════════════════
    
    init() {
        this.loadFromStorage();
        this.updateUI();
        this.setupEventListeners();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحميل من التخزين المحلي
    // ═══════════════════════════════════════════════════════════════════
    
    loadFromStorage() {
        try {
            const savedCart = localStorage.getItem(CONFIG.STORAGE_KEYS.CART);
            if (savedCart) {
                const data = JSON.parse(savedCart);
                this.items = data.items || [];
                this.coupon = data.coupon || null;
                this.shippingMethod = data.shippingMethod || null;
            }
        } catch (e) {
            console.error('خطأ في تحميل السلة:', e);
            this.items = [];
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // حفظ في التخزين المحلي
    // ═══════════════════════════════════════════════════════════════════
    
    saveToStorage() {
        try {
            const data = {
                items: this.items,
                coupon: this.coupon,
                shippingMethod: this.shippingMethod,
                timestamp: Date.now()
            };
            localStorage.setItem(CONFIG.STORAGE_KEYS.CART, JSON.stringify(data));
        } catch (e) {
            console.error('خطأ في حفظ السلة:', e);
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد المستمعين
    // ═══════════════════════════════════════════════════════════════════
    
    setupEventListeners() {
        // تحديث العداد عند فتح الصفحة
        document.addEventListener('DOMContentLoaded', () => {
            this.updateCartCount();
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إضافة منتج للسلة
    // ═══════════════════════════════════════════════════════════════════
    
    add(product, quantity = 1, options = {}) {
        if (!product || !product.id) {
            console.error('منتج غير صالح');
            return false;
        }
        
        // التحقق من المخزون
        if (product.stock < quantity) {
            UIManager.showToast(I18N.t('product.low_stock'), 'warning');
            return false;
        }
        
        // إنشاء معرف فريد للمنتج مع الخيارات
        const itemId = this.generateItemId(product.id, options);
        
        // التحقق من وجود المنتج مسبقاً
        const existingIndex = this.items.findIndex(item => item.id === itemId);
        
        if (existingIndex >= 0) {
            // تحديث الكمية إذا كان المنتج موجوداً
            const newQuantity = this.items[existingIndex].quantity + quantity;
            if (newQuantity > product.stock) {
                UIManager.showToast(I18N.t('product.in_stock', { count: product.stock }), 'warning');
                return false;
            }
            this.items[existingIndex].quantity = newQuantity;
        } else {
            // إضافة منتج جديد
            const item = {
                id: itemId,
                productId: product.id,
                name: product.name,
                nameEn: product.nameEn,
                price: product.price,
                salePrice: product.salePrice,
                image: product.image,
                thumbnail: product.thumbnail,
                category: product.category,
                stock: product.stock,
                quantity: quantity,
                options: options,
                addedAt: Date.now()
            };
            this.items.push(item);
        }
        
        this.saveToStorage();
        this.updateUI();
        UIManager.showToast(I18N.t('cart.added_success'), 'success');
        return true;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إنشاء معرف فريد
    // ═══════════════════════════════════════════════════════════════════
    
    generateItemId(productId, options = {}) {
        const optionKeys = Object.keys(options).sort();
        const optionString = optionKeys.map(k => `${k}:${options[k]}`).join(',');
        return optionString ? `${productId}_${btoa(optionString)}` : productId.toString();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إزالة منتج من السلة
    // ═══════════════════════════════════════════════════════════════════
    
    remove(itemId) {
        const index = this.items.findIndex(item => item.id === itemId);
        if (index >= 0) {
            this.items.splice(index, 1);
            this.saveToStorage();
            this.updateUI();
            UIManager.showToast(I18N.t('cart.removed_success'), 'success');
            return true;
        }
        return false;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث كمية المنتج
    // ═══════════════════════════════════════════════════════════════════
    
    updateQuantity(itemId, quantity) {
        const item = this.items.find(item => item.id === itemId);
        if (!item) return false;
        
        if (quantity <= 0) {
            return this.remove(itemId);
        }
        
        if (quantity > item.stock) {
            UIManager.showToast(I18N.t('product.in_stock', { count: item.stock }), 'warning');
            return false;
        }
        
        item.quantity = quantity;
        this.saveToStorage();
        this.updateUI();
        return true;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // مسح السلة بالكامل
    // ═══════════════════════════════════════════════════════════════════
    
    clear() {
        this.items = [];
        this.coupon = null;
        this.shippingMethod = null;
        this.saveToStorage();
        this.updateUI();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تطبيق كوبون الخصم
    // ═══════════════════════════════════════════════════════════════════
    
    async applyCoupon(code) {
        if (!code || code.trim() === '') {
            UIManager.showToast(I18N.t('form.required'), 'warning');
            return false;
        }
        
        try {
            const response = await api.post(API_ENDPOINTS.COUPONS.VALIDATE, { code });
            if (response.valid) {
                this.coupon = {
                    code: code,
                    discount: response.discount,
                    type: response.type,
                    minPurchase: response.minPurchase
                };
                this.saveToStorage();
                this.updateUI();
                UIManager.showToast('تم تطبيق الكوبون بنجاح', 'success');
                return true;
            } else {
                UIManager.showToast('كوبون غير صالح', 'error');
                return false;
            }
        } catch (e) {
            // استخدام كوبون تجريبي للعرض
            this.coupon = {
                code: code,
                discount: 10,
                type: 'percentage',
                minPurchase: 100
            };
            this.saveToStorage();
            this.updateUI();
            UIManager.showToast('تم تطبيق الكوبون بنجاح', 'success');
            return true;
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إزالة كوبون الخصم
    // ═══════════════════════════════════════════════════════════════════
    
    removeCoupon() {
        this.coupon = null;
        this.saveToStorage();
        this.updateUI();
        UIManager.showToast('تم إزالة الكوبون', 'info');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديد طريقة الشحن
    // ═══════════════════════════════════════════════════════════════════
    
    setShippingMethod(method) {
        this.shippingMethod = method;
        this.saveToStorage();
        this.updateUI();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // حساب المجاميع
    // ═══════════════════════════════════════════════════════════════════
    
    getTotals() {
        const subtotal = this.items.reduce((sum, item) => {
            const price = item.salePrice || item.price;
            return sum + (price * item.quantity);
        }, 0);
        
        const discount = this.coupon ? this.calculateDiscount(subtotal) : 0;
        const afterDiscount = subtotal - discount;
        const shipping = this.shippingMethod ? this.shippingMethod.price : 0;
        const tax = afterDiscount * 0.15; // ضريبة القيمة المضافة 15%
        const total = afterDiscount + shipping + tax;
        
        return {
            subtotal,
            discount,
            afterDiscount,
            shipping,
            tax,
            total,
            itemCount: this.items.reduce((sum, item) => sum + item.quantity, 0),
            productCount: this.items.length
        };
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // حساب قيمة الخصم
    // ═══════════════════════════════════════════════════════════════════
    
    calculateDiscount(subtotal) {
        if (!this.coupon) return 0;
        
        if (subtotal < this.coupon.minPurchase) {
            return 0;
        }
        
        if (this.coupon.type === 'percentage') {
            return subtotal * (this.coupon.discount / 100);
        } else {
            return Math.min(this.coupon.discount, subtotal);
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تنسيق السعر
    // ═══════════════════════════════════════════════════════════════════
    
    formatPrice(amount) {
        const rate = I18N.currencyRates[I18N.currentCurrency] || 1;
        const converted = amount * rate;
        const symbol = I18N.currentCurrencyData?.symbol || 'ر.س';
        return `${symbol} ${I18N.formatNumber(converted.toFixed(2))}`;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث واجهة المستخدم
    // ═══════════════════════════════════════════════════════════════════
    
    updateUI() {
        this.updateCartCount();
        this.updateCartSidebar();
        this.updateCartPage();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث عداد السلة
    // ═══════════════════════════════════════════════════════════════════
    
    updateCartCount() {
        const countElements = document.querySelectorAll('[data-cart-count]');
        const totals = this.getTotals();
        
        countElements.forEach(el => {
            el.textContent = totals.itemCount;
            el.classList.toggle('empty', totals.itemCount === 0);
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث الشريط الجانبي للسلة
    // ═══════════════════════════════════════════════════════════════════
    
    updateCartSidebar() {
        const sidebar = document.getElementById('cart-sidebar');
        if (!sidebar) return;
        
        const content = sidebar.querySelector('.sidebar-content');
        if (!content) return;
        
        if (this.items.length === 0) {
            content.innerHTML = `
                <div class="empty-cart">
                    <div class="empty-cart-icon">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="9" cy="21" r="1"/>
                            <circle cx="20" cy="21" r="1"/>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                        </svg>
                    </div>
                    <h3 class="empty-cart-title">${I18N.t('cart.empty')}</h3>
                    <p class="empty-cart-message">${I18N.t('cart.empty_message')}</p>
                    <a href="shop.html" class="btn btn-primary">${I18N.t('cart.add')}</a>
                </div>
            `;
            return;
        }
        
        let html = '<div class="cart-items">';
        
        this.items.forEach(item => {
            const price = item.salePrice || item.price;
            html += `
                <div class="cart-item" data-cart-item="${item.id}">
                    <div class="cart-item-image">
                        <img src="${item.thumbnail || item.image}" alt="${item.name}" onerror="this.src='${CONFIG.IMAGES.PLACEHOLDER}'">
                    </div>
                    <div class="cart-item-details">
                        <h4 class="cart-item-name">${item.name}</h4>
                        <div class="cart-item-options">
                            ${Object.entries(item.options).map(([key, value]) => `
                                <span class="cart-item-option">${key}: ${value}</span>
                            `).join('')}
                        </div>
                        <div class="cart-item-price">${this.formatPrice(price)}</div>
                        <div class="cart-item-quantity">
                            <button class="quantity-btn" onclick="CartManager.updateQuantity('${item.id}', ${item.quantity - 1})">-</button>
                            <span class="quantity-value">${item.quantity}</span>
                            <button class="quantity-btn" onclick="CartManager.updateQuantity('${item.id}', ${item.quantity + 1})" ${item.quantity >= item.stock ? 'disabled' : ''}>+</button>
                        </div>
                    </div>
                    <button class="cart-item-remove" onclick="CartManager.remove('${item.id}')">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                    </button>
                </div>
            `;
        });
        
        html += '</div>';
        
        const totals = this.getTotals();
        html += `
            <div class="cart-summary">
                <div class="cart-summary-row">
                    <span>${I18N.t('cart.subtotal')}</span>
                    <span>${this.formatPrice(totals.subtotal)}</span>
                </div>
                ${totals.discount > 0 ? `
                    <div class="cart-summary-row discount">
                        <span>${I18N.t('cart.discount')}</span>
                        <span>-${this.formatPrice(totals.discount)}</span>
                    </div>
                ` : ''}
                <div class="cart-summary-row">
                    <span>${I18N.t('cart.shipping')}</span>
                    <span>${totals.shipping === 0 ? I18N.t('cart.free') : this.formatPrice(totals.shipping)}</span>
                </div>
                <div class="cart-summary-row total">
                    <span>${I18N.t('cart.total')}</span>
                    <span>${this.formatPrice(totals.total)}</span>
                </div>
            </div>
            <div class="cart-actions">
                <a href="checkout.html" class="btn btn-primary btn-full">${I18N.t('cart.checkout')}</a>
                <a href="shop.html" class="btn btn-outline btn-full">${I18N.t('cart.continue')}</a>
            </div>
        `;
        
        content.innerHTML = html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث صفحة السلة
    // ═══════════════════════════════════════════════════════════════════
    
    updateCartPage() {
        const page = document.getElementById('cart-page');
        if (!page) return;
        
        const itemsContainer = page.querySelector('.cart-items-container');
        const summaryContainer = page.querySelector('.cart-summary-container');
        
        if (!itemsContainer || !summaryContainer) return;
        
        if (this.items.length === 0) {
            itemsContainer.innerHTML = `
                <div class="empty-cart-page">
                    <div class="empty-cart-icon">
                        <svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="9" cy="21" r="1"/>
                            <circle cx="20" cy="21" r="1"/>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                        </svg>
                    </div>
                    <h2 class="empty-cart-title">${I18N.t('cart.empty')}</h2>
                    <p class="empty-cart-message">${I18N.t('cart.empty_message')}</p>
                    <a href="shop.html" class="btn btn-primary btn-lg">${I18N.t('cart.add')}</a>
                </div>
            `;
            summaryContainer.style.display = 'none';
            return;
        }
        
        summaryContainer.style.display = 'block';
        
        let html = '';
        this.items.forEach(item => {
            const price = item.salePrice || item.price;
            html += `
                <div class="cart-item-row" data-cart-item="${item.id}">
                    <div class="cart-item-image">
                        <img src="${item.thumbnail || item.image}" alt="${item.name}" onerror="this.src='${CONFIG.IMAGES.PLACEHOLDER}'">
                    </div>
                    <div class="cart-item-info">
                        <h3 class="cart-item-name">
                            <a href="product.html?id=${item.productId}">${item.name}</a>
                        </h3>
                        <div class="cart-item-meta">
                            <span class="cart-item-sku">${I18N.t('product.sku')}: ${item.productId}</span>
                            <span class="cart-item-category">${item.category}</span>
                        </div>
                        <div class="cart-item-options">
                            ${Object.entries(item.options).map(([key, value]) => `
                                <span class="cart-item-option">${key}: ${value}</span>
                            `).join('')}
                        </div>
                    </div>
                    <div class="cart-item-pricing">
                        <div class="cart-item-price">${this.formatPrice(price)}</div>
                        ${item.salePrice ? `
                            <div class="cart-item-original-price">${this.formatPrice(item.price)}</div>
                        ` : ''}
                    </div>
                    <div class="cart-item-quantity">
                        <div class="quantity-input">
                            <button class="quantity-btn" onclick="CartManager.updateQuantity('${item.id}', ${item.quantity - 1})">-</button>
                            <input type="number" class="quantity-value" value="${item.quantity}" min="1" max="${item.stock}" onchange="CartManager.updateQuantity('${item.id}', parseInt(this.value))">
                            <button class="quantity-btn" onclick="CartManager.updateQuantity('${item.id}', ${item.quantity + 1})" ${item.quantity >= item.stock ? 'disabled' : ''}>+</button>
                        </div>
                    </div>
                    <div class="cart-item-total">
                        ${this.formatPrice(price * item.quantity)}
                    </div>
                    <div class="cart-item-actions">
                        <button class="cart-item-remove" onclick="CartManager.remove('${item.id}')">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"/>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                            </svg>
                        </button>
                    </div>
                </div>
            `;
        });
        
        itemsContainer.innerHTML = html;
        
        // تحديث الملخص
        const totals = this.getTotals();
        const summaryHtml = `
            <div class="summary-section">
                <h3 class="summary-title">${I18N.t('checkout.order_summary')}</h3>
                <div class="summary-row">
                    <span>${I18N.t('cart.subtotal')} (${totals.itemCount} ${I18N.t('cart.items', { count: totals.itemCount })})</span>
                    <span>${this.formatPrice(totals.subtotal)}</span>
                </div>
                ${this.coupon ? `
                    <div class="summary-row discount">
                        <span>${I18N.t('cart.discount')} (${this.coupon.code})</span>
                        <span>-${this.formatPrice(totals.discount)}</span>
                    </div>
                    <button class="remove-coupon" onclick="CartManager.removeCoupon()">إزالة</button>
                ` : ''}
                <div class="coupon-input-group">
                    <input type="text" class="form-input" id="coupon-input" placeholder="${I18N.t('checkout.promo_code')}">
                    <button class="btn btn-outline" onclick="CartManager.applyCoupon(document.getElementById('coupon-input').value)">
                        ${I18N.t('checkout.apply')}
                    </button>
                </div>
                <div class="summary-row">
                    <span>${I18N.t('cart.shipping')}</span>
                    <span>${totals.shipping === 0 ? I18N.t('cart.free') : this.formatPrice(totals.shipping)}</span>
                </div>
                <div class="summary-row">
                    <span>${I18N.t('cart.tax')} (15%)</span>
                    <span>${this.formatPrice(totals.tax)}</span>
                </div>
                <div class="summary-row total">
                    <span>${I18N.t('cart.total')}</span>
                    <span>${this.formatPrice(totals.total)}</span>
                </div>
                <a href="checkout.html" class="btn btn-primary btn-full btn-lg">${I18N.t('checkout.place_order')}</a>
            </div>
        `;
        
        summaryContainer.innerHTML = summaryHtml;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    getItems() {
        return this.items;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // التحقق من توفر المنتج
    // ═══════════════════════════════════════════════════════════════════
    
    isAvailable(productId, quantity = 1) {
        const item = this.items.find(item => item.productId === productId);
        if (!item) return quantity <= product.stock;
        return (item.quantity + quantity) <= product.stock;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // نقل المنتجات لقائمة الأمنيات
    // ═══════════════════════════════════════════════════════════════════
    
    moveToWishlist(itemId) {
        const item = this.items.find(i => i.id === itemId);
        if (item) {
            WishlistManager.add(item);
            this.remove(itemId);
            UIManager.showToast(I18N.t('wishlist.added_success'), 'success');
        }
    }
};

// ═══════════════════════════════════════════════════════════════════════
// إدارة قائمة الأمنيات
// ═══════════════════════════════════════════════════════════════════════

const WishlistManager = {
    items: [],
    
    init() {
        this.loadFromStorage();
    },
    
    loadFromStorage() {
        try {
            const saved = localStorage.getItem(CONFIG.STORAGE_KEYS.WISHLIST);
            if (saved) {
                this.items = JSON.parse(saved);
            }
        } catch (e) {
            this.items = [];
        }
    },
    
    saveToStorage() {
        try {
            localStorage.setItem(CONFIG.STORAGE_KEYS.WISHLIST, JSON.stringify(this.items));
        } catch (e) {
            console.error('خطأ في حفظ قائمة الأمنيات:', e);
        }
    },
    
    add(product) {
        if (this.items.some(item => item.id === product.id)) {
            UIManager.showToast('المنتج موجود بالفعل في قائمة الأمنيات', 'warning');
            return false;
        }
        
        if (this.items.length >= CONFIG.MAX_WISHLIST_ITEMS) {
            UIManager.showToast('قائمة الأمنيات ممتلئة', 'warning');
            return false;
        }
        
        this.items.push({
            id: product.id,
            name: product.name,
            nameEn: product.nameEn,
            price: product.price,
            salePrice: product.salePrice,
            image: product.image,
            thumbnail: product.thumbnail,
            category: product.category,
            addedAt: Date.now()
        });
        
        this.saveToStorage();
        this.updateWishlistCount();
        return true;
    },
    
    remove(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveToStorage();
        this.updateWishlistCount();
        this.updateUI();
    },
    
    toggle(product) {
        if (this.items.some(item => item.id === product.id)) {
            this.remove(product.id);
            return false;
        } else {
            this.add(product);
            return true;
        }
    },
    
    isInWishlist(productId) {
        return this.items.some(item => item.id === productId);
    },
    
    updateWishlistCount() {
        const countElements = document.querySelectorAll('[data-wishlist-count]');
        countElements.forEach(el => {
            el.textContent = this.items.length;
            el.classList.toggle('empty', this.items.length === 0);
        });
    },
    
    updateUI() {
        // تحديث أيقونات القلب في بطاقات المنتجات
        const wishlistBtns = document.querySelectorAll('[data-wishlist-btn]');
        wishlistBtns.forEach(btn => {
            const productId = btn.dataset.productId;
            if (this.isInWishlist(productId)) {
                btn.classList.add('active');
                btn.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                `;
            } else {
                btn.classList.remove('active');
                btn.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                `;
            }
        });
    },
    
    getItems() {
        return this.items;
    }
};

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    CartManager.init();
    WishlistManager.init();
});

// تصدير الوحدات
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CartManager, WishlistManager };
}
