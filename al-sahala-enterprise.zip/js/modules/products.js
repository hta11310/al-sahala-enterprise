/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  إدارة المنتجات - Al-Sahala Enterprise                               ║
 * ║  Product Management - عرض، تصفية، تفاصيل المنتجات                   ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const ProductManager = {
    // ═══════════════════════════════════════════════════════════════════
    // البيانات
    // ═══════════════════════════════════════════════════════════════════
    
    products: [],
    categories: [],
    featuredProducts: [],
    filteredProducts: [],
    currentFilters: {},
    currentPage: 1,
    totalPages: 1,
    isLoading: false,
    
    // ═══════════════════════════════════════════════════════════════════
    // البيانات الوهمية للعرض
    // ═══════════════════════════════════════════════════════════════════
    
    mockProducts: [
        {
            id: 1,
            name: 'هاتف ذكي سامسونج Galaxy S24',
            nameEn: 'Samsung Galaxy S24 Smartphone',
            description: 'هاتف ذكي رائد مع معالج قوي وكاميرا مذهلة',
            price: 3299,
            salePrice: 2899,
            discount: 12,
            category: 'electronics',
            brand: 'Samsung',
            rating: 4.8,
            reviews: 156,
            stock: 50,
            images: ['https://picsum.photos/400/400?random=1'],
            thumbnail: 'https://picsum.photos/300/300?random=1',
            isNew: true,
            isHot: true,
            isSale: true,
            variants: {
                colors: ['black', 'white', 'purple'],
                sizes: ['128GB', '256GB', '512GB']
            }
        },
        {
            id: 2,
            name: 'لابتوب ماكbook Air M3',
            nameEn: 'MacBook Air M3',
            description: 'لابتوب خفيف وأنيق مع أداء استثنائي',
            price: 5499,
            salePrice: null,
            category: 'electronics',
            brand: 'Apple',
            rating: 4.9,
            reviews: 234,
            stock: 30,
            images: ['https://picsum.photos/400/400?random=2'],
            thumbnail: 'https://picsum.photos/300/300?random=2',
            isNew: true,
            isHot: false,
            isSale: false,
            variants: {
                colors: ['silver', 'space-gray'],
                sizes: ['256GB', '512GB']
            }
        },
        {
            id: 3,
            name: 'ساعة ذكية Apple Watch Ultra 2',
            nameEn: 'Apple Watch Ultra 2',
            description: 'ساعة ذكية متينة مع ميزات رياضية متقدمة',
            price: 3299,
            salePrice: 2999,
            discount: 9,
            category: 'electronics',
            brand: 'Apple',
            rating: 4.7,
            reviews: 89,
            stock: 25,
            images: ['https://picsum.photos/400/400?random=3'],
            thumbnail: 'https://picsum.photos/300/300?random=3',
            isNew: false,
            isHot: true,
            isSale: true,
            variants: {
                colors: ['titanium']
            }
        },
        {
            id: 4,
            name: 'سماعات AirPods Pro 2',
            nameEn: 'AirPods Pro 2nd Generation',
            description: 'سماعات لاسلكية مع إلغاء الضوضاء النشط',
            price: 1099,
            salePrice: 949,
            discount: 14,
            category: 'electronics',
            brand: 'Apple',
            rating: 4.6,
            reviews: 312,
            stock: 100,
            images: ['https://picsum.photos/400/400?random=4'],
            thumbnail: 'https://picsum.photos/300/300?random=4',
            isNew: false,
            isHot: true,
            isSale: true,
            variants: {
                colors: ['white']
            }
        },
        {
            id: 5,
            name: 'قميص قطني رجالي كلاسيك',
            nameEn: 'Classic Cotton Men's Shirt',
            description: 'قميص قطني مريح ومناسب للمناسبات',
            price: 189,
            salePrice: 149,
            discount: 21,
            category: 'clothing',
            brand: 'Local Brand',
            rating: 4.4,
            reviews: 67,
            stock: 200,
            images: ['https://picsum.photos/400/400?random=5'],
            thumbnail: 'https://picsum.photos/300/300?random=5',
            isNew: true,
            isHot: false,
            isSale: true,
            variants: {
                colors: ['white', 'blue', 'black'],
                sizes: ['S', 'M', 'L', 'XL']
            }
        },
        {
            id: 6,
            name: 'فستان أنيق نسائي',
            nameEn: 'Elegant Women's Dress',
            description: 'فستان أنيق للمناسبات السهرية',
            price: 459,
            salePrice: null,
            category: 'clothing',
            brand: 'Fashion Brand',
            rating: 4.5,
            reviews: 43,
            stock: 80,
            images: ['https://picsum.photos/400/400?random=6'],
            thumbnail: 'https://picsum.photos/300/300?random=6',
            isNew: true,
            isHot: false,
            isSale: false,
            variants: {
                colors: ['red', 'black', 'beige'],
                sizes: ['XS', 'S', 'M', 'L']
            }
        },
        {
            id: 7,
            name: 'عناية بالبشرة - مجموعة الترطيب',
            nameEn: 'Skincare Hydration Set',
            description: 'مجموعة متكاملة للعناية وترطيب البشرة',
            price: 399,
            salePrice: 329,
            discount: 18,
            category: 'beauty',
            brand: 'Olay',
            rating: 4.7,
            reviews: 198,
            stock: 150,
            images: ['https://picsum.photos/400/400?random=7'],
            thumbnail: 'https://picsum.photos/300/300?random=7',
            isNew: false,
            isHot: true,
            isSale: true,
            variants: {}
        },
        {
            id: 8,
            name: 'خلاط كهربائي احترافي',
            nameEn: 'Professional Electric Blender',
            description: 'خلاط قوي لتحضير العصائر وال smoothies',
            price: 699,
            salePrice: 549,
            discount: 21,
            category: 'home',
            brand: 'Philips',
            rating: 4.6,
            reviews: 87,
            stock: 60,
            images: ['https://picsum.photos/400/400?random=8'],
            thumbnail: 'https://picsum.photos/300/300?random=8',
            isNew: false,
            isHot: false,
            isSale: true,
            variants: {
                colors: ['black', 'silver']
            }
        },
        {
            id: 9,
            name: 'حذاء رياضي نايك اير ماكس',
            nameEn: 'Nike Air Max Sneakers',
            description: 'حذاء رياضي مريح وأنيق للرياضة واليومية',
            price: 799,
            salePrice: 649,
            discount: 19,
            category: 'sports',
            brand: 'Nike',
            rating: 4.8,
            reviews: 245,
            stock: 120,
            images: ['https://picsum.photos/400/400?random=9'],
            thumbnail: 'https://picsum.photos/300/300?random=9',
            isNew: true,
            isHot: true,
            isSale: true,
            variants: {
                colors: ['black', 'white', 'red'],
                sizes: ['39', '40', '41', '42', '43', '44']
            }
        },
        {
            id: 10,
            name: 'رواية - الماضي القريب',
            nameEn: 'Novel - The Near Past',
            description: 'رواية مثيرة من تأليف كاتب عربي مشهور',
            price: 79,
            salePrice: 59,
            discount: 25,
            category: 'books',
            brand: 'Dar Al-Machreq',
            rating: 4.3,
            reviews: 34,
            stock: 500,
            images: ['https://picsum.photos/400/400?random=10'],
            thumbnail: 'https://picsum.photos/300/300?random=10',
            isNew: true,
            isHot: false,
            isSale: true,
            variants: {}
        },
        {
            id: 11,
            name: 'لعبة فيديو - FIFA 25',
            nameEn: 'FIFA 25 Video Game',
            description: 'أحدث إصدار من لعبة FIFA الشهيرة',
            price: 299,
            salePrice: 249,
            discount: 17,
            category: 'toys',
            brand: 'EA Sports',
            rating: 4.5,
            reviews: 167,
            stock: 200,
            images: ['https://picsum.photos/400/400?random=11'],
            thumbnail: 'https://picsum.photos/300/300?random=11',
            isNew: true,
            isHot: true,
            isSale: true,
            variants: {
                platforms: ['PS5', 'Xbox', 'PC']
            }
        },
        {
            id: 12,
            name: 'حفاضات أطفال بامبرز',
            nameEn: 'Pampers Baby Diapers',
            description: 'حفاضات ناعمة ومريحة للأطفال',
            price: 189,
            salePrice: 159,
            discount: 16,
            category: 'baby',
            brand: 'Pampers',
            rating: 4.7,
            reviews: 456,
            stock: 300,
            images: ['https://picsum.photos/400/400?random=12'],
            thumbnail: 'https://picsum.photos/300/300?random=12',
            isNew: false,
            isHot: true,
            isSale: true,
            variants: {
                sizes: ['Newborn', '1', '2', '3', '4']
            }
        }
    ],
    
    mockCategories: [
        { id: 'all', name: 'الكل', nameEn: 'All', icon: 'grid', count: 12 },
        { id: 'electronics', name: 'الإلكترونيات', nameEn: 'Electronics', icon: 'cpu', count: 4 },
        { id: 'clothing', name: 'الأزياء', nameEn: 'Clothing', icon: 'shirt', count: 2 },
        { id: 'beauty', name: 'الجمال', nameEn: 'Beauty', icon: 'sparkles', count: 1 },
        { id: 'home', name: 'المنزل والمطبخ', nameEn: 'Home & Kitchen', icon: 'home', count: 1 },
        { id: 'sports', name: 'رياضة', nameEn: 'Sports', icon: 'dumbbell', count: 1 },
        { id: 'books', name: 'الكتب', nameEn: 'Books', icon: 'book', count: 1 },
        { id: 'toys', name: 'الألعاب', nameEn: 'Toys', icon: 'gamepad', count: 1 },
        { id: 'baby', name: 'الرضع', nameEn: 'Baby', icon: 'baby', count: 1 }
    ],
    
    // ═══════════════════════════════════════════════════════════════════
    // التهيئة
    // ═══════════════════════════════════════════════════════════════════
    
    init() {
        this.loadProducts();
        this.loadCategories();
        this.setupEventListeners();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحميل المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    async loadProducts() {
        this.isLoading = true;
        this.showLoading();
        
        try {
            // محاولة تحميل من التخزين المؤقت أولاً
            const cached = cache.get('products');
            if (cached) {
                this.products = cached;
                this.filteredProducts = cached;
                this.hideLoading();
                this.renderProducts();
                return;
            }
            
            // محاكاة طلب API
            await this.simulateAPIRequest();
            
            this.filteredProducts = this.products;
            cache.set('products', this.products);
            this.hideLoading();
            this.renderProducts();
        } catch (e) {
            console.error('خطأ في تحميل المنتجات:', e);
            this.hideLoading();
            this.renderProducts();
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // محاكاة طلب API
    // ═══════════════════════════════════════════════════════════════════
    
    simulateAPIRequest() {
        return new Promise(resolve => {
            setTimeout(() => {
                this.products = [...this.mockProducts];
                this.featuredProducts = this.products.filter(p => p.isHot || p.isNew);
                resolve();
            }, 500);
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحميل الفئات
    // ═══════════════════════════════════════════════════════════════════
    
    loadCategories() {
        this.categories = [...this.mockCategories];
        this.renderCategories();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعداد المستمعين
    // ═══════════════════════════════════════════════════════════════════
    
    setupEventListeners() {
        // تصفية حسب الفئة
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-category]')) {
                const category = e.target.dataset.category;
                this.filterByCategory(category);
            }
        });
        
        // تصفية حسب السعر
        const priceFilter = document.getElementById('price-filter');
        if (priceFilter) {
            priceFilter.addEventListener('change', () => {
                this.filterByPrice(priceFilter.value);
            });
        }
        
        // ترتيب المنتجات
        const sortSelect = document.getElementById('sort-select');
        if (sortSelect) {
            sortSelect.addEventListener('change', () => {
                this.sortProducts(sortSelect.value);
            });
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض حالة التحميل
    // ═══════════════════════════════════════════════════════════════════
    
    showLoading() {
        const grid = document.getElementById('products-grid');
        if (!grid) return;
        
        let html = '<div class="products-grid">';
        for (let i = 0; i < CONFIG.LOADER.SKELETON_COUNT; i++) {
            html += this.getSkeletonCard();
        }
        html += '</div>';
        grid.innerHTML = html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إخفاء حالة التحميل
    // ═══════════════════════════════════════════════════════════════════
    
    hideLoading() {
        this.isLoading = false;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // هيكل بطاقة التحميل
    // ═══════════════════════════════════════════════════════════════════
    
    getSkeletonCard() {
        return `
            <div class="product-card skeleton-card">
                <div class="product-card-image skeleton skeleton-image"></div>
                <div class="product-card-content">
                    <div class="skeleton skeleton-text"></div>
                    <div class="skeleton skeleton-text" style="width: 60%"></div>
                    <div class="skeleton skeleton-button"></div>
                </div>
            </div>
        `;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    renderProducts() {
        const grid = document.getElementById('products-grid');
        if (!grid) return;
        
        if (this.filteredProducts.length === 0) {
            grid.innerHTML = `
                <div class="no-products">
                    <div class="no-products-icon">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="11" cy="11" r="8"/>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                    </div>
                    <h3>${I18N.t('search.no_results')}</h3>
                    <p>${I18N.t('search.try_different')}</p>
                </div>
            `;
            return;
        }
        
        let html = '<div class="products-grid">';
        
        this.filteredProducts.forEach(product => {
            html += this.getProductCard(product);
        });
        
        html += '</div>';
        grid.innerHTML = html;
        
        // تحديث عدد النتائج
        const resultsCount = document.getElementById('results-count');
        if (resultsCount) {
            resultsCount.textContent = this.filteredProducts.length;
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على بطاقة المنتج
    // ═══════════════════════════════════════════════════════════════════
    
    getProductCard(product) {
        const price = product.salePrice || product.price;
        const inWishlist = WishlistManager.isInWishlist(product.id);
        
        return `
            <div class="product-card" data-product-id="${product.id}">
                <div class="product-card-image">
                    <img src="${product.thumbnail || CONFIG.IMAGES.PLACEHOLDER}" 
                         alt="${product.name}" 
                         loading="lazy"
                         onerror="this.src='${CONFIG.IMAGES.PLACEHOLDER}'">
                    
                    <div class="product-card-badges">
                        ${product.isNew ? '<span class="product-badge product-badge-new">' + I18N.t('product.new') + '</span>' : ''}
                        ${product.isHot ? '<span class="product-badge product-badge-hot">' + I18N.t('event.hot_deal') + '</span>' : ''}
                        ${product.isSale ? '<span class="product-badge product-badge-sale">' + I18N.t('event.sale', { percent: product.discount }) + '</span>' : ''}
                    </div>
                    
                    <div class="product-card-actions">
                        <button class="action-btn" data-wishlist-btn data-product-id="${product.id}" onclick="handleWishlist(${product.id})">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="${inWishlist ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>
                        <button class="action-btn" onclick="showQuickView(${product.id})">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                        <button class="action-btn" onclick="handleCompare(${product.id})">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>
                            </svg>
                        </button>
                    </div>
                </div>
                
                <div class="product-card-content">
                    <span class="product-card-category">${I18N.t(`category.${product.category}`)}</span>
                    <h3 class="product-card-title">
                        <a href="product.html?id=${product.id}">${product.name}</a>
                    </h3>
                    
                    <div class="product-card-rating">
                        <div class="stars">
                            ${this.getStarsHtml(product.rating)}
                        </div>
                        <span class="rating-count">(${product.reviews})</span>
                    </div>
                    
                    <div class="product-card-pricing">
                        <span class="product-price">${CartManager.formatPrice(price)}</span>
                        ${product.salePrice ? `<span class="product-price-old">${CartManager.formatPrice(product.price)}</span>` : ''}
                        ${product.salePrice ? `<span class="product-discount">-${product.discount}%</span>` : ''}
                    </div>
                    
                    ${product.variants && product.variants.colors ? `
                        <div class="product-card-variants">
                            ${product.variants.colors.slice(0, 5).map(color => `
                                <span class="variant-swatch" style="background-color: ${color}" title="${I18N.t(`product.colors.${color}`)}" data-color="${color}"></span>
                            `).join('')}
                        </div>
                    ` : ''}
                    
                    <button class="product-card-btn" onclick="handleAddToCart(${product.id})">
                        ${I18N.t('product.add_to_cart')}
                    </button>
                </div>
            </div>
        `;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض النجوم
    // ═══════════════════════════════════════════════════════════════════
    
    getStarsHtml(rating) {
        let html = '';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                html += '<svg class="star" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
            } else if (i - 0.5 <= rating) {
                html += '<svg class="star" viewBox="0 0 24 24" style="fill: url(#half-star)"><defs><linearGradient id="half-star"><stop offset="50%" stop-color="currentColor"/><stop offset="50%" stop-color="transparent"/></linearGradient></defs><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
            } else {
                html += '<svg class="star empty" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
            }
        }
        return html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض الفئات
    // ═══════════════════════════════════════════════════════════════════
    
    renderCategories() {
        const container = document.getElementById('categories-list');
        if (!container) return;
        
        let html = '';
        this.categories.forEach(category => {
            html += `
                <li class="sidebar-category-item">
                    <a href="#" class="sidebar-category-link" data-category="${category.id}">
                        <span>${category.name}</span>
                        <span class="sidebar-category-count">${category.count}</span>
                    </a>
                </li>
            `;
        });
        container.innerHTML = html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تصفية حسب الفئة
    // ═══════════════════════════════════════════════════════════════════
    
    filterByCategory(categoryId) {
        this.currentFilters.category = categoryId;
        
        if (categoryId === 'all') {
            this.filteredProducts = [...this.products];
        } else {
            this.filteredProducts = this.products.filter(p => p.category === categoryId);
        }
        
        this.applyFilters();
        this.renderProducts();
        this.updateActiveCategory(categoryId);
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تصفية حسب السعر
    // ═══════════════════════════════════════════════════════════════════
    
    filterByPrice(range) {
        const [min, max] = range.split('-').map(Number);
        this.currentFilters.priceRange = { min, max };
        
        this.filteredProducts = this.products.filter(p => {
            const price = p.salePrice || p.price;
            return price >= min && (max ? price <= max : true);
        });
        
        this.applyFilters();
        this.renderProducts();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // ترتيب المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    sortProducts(sortBy) {
        switch (sortBy) {
            case 'newest':
                this.filteredProducts.sort((a, b) => b.id - a.id);
                break;
            case 'price-low':
                this.filteredProducts.sort((a, b) => (a.salePrice || a.price) - (b.salePrice || b.price));
                break;
            case 'price-high':
                this.filteredProducts.sort((a, b) => (b.salePrice || b.price) - (a.salePrice || a.price));
                break;
            case 'popular':
                this.filteredProducts.sort((a, b) => b.reviews - a.reviews);
                break;
            case 'rating':
                this.filteredProducts.sort((a, b) => b.rating - a.rating);
                break;
        }
        this.renderProducts();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تطبيق الفلاتر
    // ═══════════════════════════════════════════════════════════════════
    
    applyFilters() {
        // يمكن إضافة فلاتر إضافية هنا
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تحديث الفئة النشطة
    // ═══════════════════════════════════════════════════════════════════
    
    updateActiveCategory(categoryId) {
        const links = document.querySelectorAll('[data-category]');
        links.forEach(link => {
            if (link.dataset.category === categoryId) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على منتج بالمعرف
    // ═══════════════════════════════════════════════════════════════════
    
    getProductById(id) {
        return this.products.find(p => p.id === parseInt(id)) || null;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على المنتجات المميزة
    // ═══════════════════════════════════════════════════════════════════
    
    getFeaturedProducts() {
        return this.featuredProducts;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الحصول على المنتجات الجديدة
    // ═══════════════════════════════════════════════════════════════════
    
    getNewArrivals() {
        return this.products.filter(p => p.isNew).slice(0, 8);
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // البحث في المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    searchProducts(query) {
        const searchTerm = query.toLowerCase().trim();
        
        if (!searchTerm) {
            this.filteredProducts = [...this.products];
        } else {
            this.filteredProducts = this.products.filter(p => 
                p.name.toLowerCase().includes(searchTerm) ||
                p.nameEn.toLowerCase().includes(searchTerm) ||
                p.description.toLowerCase().includes(searchTerm) ||
                p.brand.toLowerCase().includes(searchTerm) ||
                p.category.toLowerCase().includes(searchTerm)
            );
        }
        
        this.renderProducts();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إضافة للمشاهدة
    // ═══════════════════════════════════════════════════════════════════
    
    addToRecentlyViewed(product) {
        let viewed = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEYS.VIEWED_PRODUCTS) || '[]');
        
        // إزالة المنتج إذا كان موجوداً
        viewed = viewed.filter(p => p.id !== product.id);
        
        // إضافة المنتج في البداية
        viewed.unshift({
            id: product.id,
            name: product.name,
            thumbnail: product.thumbnail,
            price: product.salePrice || product.price,
            viewedAt: Date.now()
        });
        
        // الاحتفاظ بآخر 20 منتج
        viewed = viewed.slice(0, CONFIG.MAX_VIEWED_PRODUCTS);
        
        localStorage.setItem(CONFIG.STORAGE_KEYS.VIEWED_PRODUCTS, JSON.stringify(viewed));
    }
};

// ═══════════════════════════════════════════════════════════════════════
// دوال مساعدة للتعامل مع المنتجات
// ═══════════════════════════════════════════════════════════════════════

function handleAddToCart(productId) {
    const product = ProductManager.getProductById(productId);
    if (product) {
        CartManager.add(product);
    }
}

function handleWishlist(productId) {
    const product = ProductManager.getProductById(productId);
    if (product) {
        const added = WishlistManager.toggle(product);
        WishlistManager.updateUI();
        UIManager.showToast(
            added ? I18N.t('wishlist.added_success') : I18N.t('wishlist.removed_success'),
            'success'
        );
    }
}

function handleCompare(productId) {
    UIManager.showToast('ميزة المقارنة قريباً', 'info');
}

function showQuickView(productId) {
    const product = ProductManager.getProductById(productId);
    if (product) {
        UIManager.showQuickView(product);
    }
}

// تصدير الوحدة
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProductManager;
}
