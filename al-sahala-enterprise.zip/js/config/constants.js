/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  الثوابت والإعدادات - Al-Sahala Enterprise                           ║
 * ║  Configuration Constants - إعدادات المنصة الأساسية                   ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const CONFIG = {
    // ═══════════════════════════════════════════════════════════════════
    // معلومات التطبيق
    // ═══════════════════════════════════════════════════════════════════
    
    APP_NAME: 'منصة ومتجر السهالة',
    APP_NAME_EN: 'Al-Sahala Platform',
    APP_VERSION: '1.0.0',
    APP_DESCRIPTION: 'منصة تسوق متكاملة مع أفضل المنتجات والخدمات',
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات اللغة
    // ═══════════════════════════════════════════════════════════════════
    
    DEFAULT_LANGUAGE: 'ar',
    SUPPORTED_LANGUAGES: ['ar', 'en'],
    RTL_LANGUAGES: ['ar', 'fa', 'he', 'ur'],
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات العملة
    // ═══════════════════════════════════════════════════════════════════
    
    DEFAULT_CURRENCY: 'SAR',
    SUPPORTED_CURRENCIES: [
        { code: 'SAR', symbol: 'ر.س', name: 'ريال سعودي', flag: '🇸🇦' },
        { code: 'AED', symbol: 'د.إ', name: 'درهم إماراتي', flag: '🇦🇪' },
        { code: 'USD', symbol: '$', name: 'دولار أمريكي', flag: '🇺🇸' },
        { code: 'EGP', symbol: 'ج.م', name: 'جنيه مصري', flag: '🇪🇬' },
        { code: 'YER', symbol: 'ر.ي', name: 'ريال يمني', flag: '🇾🇪' },
        { code: 'KWD', symbol: 'د.ك', name: 'دينار كويتي', flag: '🇰🇼' }
    ],
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات API
    // ═══════════════════════════════════════════════════════════════════
    
    API_BASE_URL: 'https://api.alsahala.com/v1',
    API_TIMEOUT: 30000,
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات التخزين المحلي
    // ═══════════════════════════════════════════════════════════════════
    
    STORAGE_KEYS: {
        CART: 'alsahala_cart',
        WISHLIST: 'alsahala_wishlist',
        USER: 'alsahala_user',
        LANGUAGE: 'alsahala_language',
        CURRENCY: 'alsahala_currency',
        RECENT_SEARCHES: 'alsahala_recent_searches',
        VIEWED_PRODUCTS: 'alsahala_viewed_products'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    PRODUCTS_PER_PAGE: 12,
    MAX_WISHLIST_ITEMS: 50,
    MAX_RECENT_SEARCHES: 10,
    MAX_VIEWED_PRODUCTS: 20,
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات التصفية
    // ═══════════════════════════════════════════════════════════════════
    
    PRICE_RANGE: {
        MIN: 0,
        MAX: 100000,
        STEP: 10
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات التخزين المؤقت
    // ═══════════════════════════════════════════════════════════════════
    
    CACHE_DURATION: {
        PRODUCTS: 5 * 60 * 1000,    // 5 دقائق
        CATEGORIES: 30 * 60 * 1000,  // 30 دقيقة
        BANNERS: 15 * 60 * 1000      // 15 دقيقة
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات الأمان
    // ═══════════════════════════════════════════════════════════════════
    
    SECURITY: {
        TOKEN_KEY: 'alsahala_auth_token',
        REFRESH_TOKEN_KEY: 'alsahala_refresh_token',
        SESSION_TIMEOUT: 30 * 60 * 1000, // 30 دقيقة
        MAX_LOGIN_ATTEMPTS: 5,
        LOCKOUT_DURATION: 15 * 60 * 1000 // 15 دقيقة
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات الصور
    // ═══════════════════════════════════════════════════════════════════
    
    IMAGES: {
        QUALITY: 85,
        FORMATS: ['webp', 'jpeg', 'png'],
        SIZES: {
            THUMBNAIL: { width: 100, height: 100 },
            SMALL: { width: 300, height: 300 },
            MEDIUM: { width: 600, height: 600 },
            LARGE: { width: 1200, height: 1200 },
            ORIGINAL: { width: 2000, height: 2000 }
        },
        PLACEHOLDER: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"%3E%3Crect fill="%23f3f4f6" width="400" height="400"/%3E%3Ctext fill="%239ca3af" font-family="sans-serif" font-size="20" x="50%25" y="50%25" text-anchor="middle" dy=".3em"%3Eصورة المنتج%3C/text%3E%3C/svg%3E'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات الإشعارات
    // ═══════════════════════════════════════════════════════════════════
    
    TOAST_DURATION: {
        DEFAULT: 3000,
        SUCCESS: 2000,
        ERROR: 5000,
        WARNING: 4000
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات التحميل
    // ═══════════════════════════════════════════════════════════════════
    
    LOADER: {
        SKELETON_COUNT: 8,
        SKELETON_DELAY: 100
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات وسائل التواصل الاجتماعي
    // ═══════════════════════════════════════════════════════════════════
    
    SOCIAL_LINKS: {
        FACEBOOK: 'https://facebook.com/alsahala',
        TWITTER: 'https://twitter.com/alsahala',
        INSTAGRAM: 'https://instagram.com/alsahala',
        SNAPCHAT: 'https://snapchat.com/add/alsahala',
        WHATSAPP: 'https://wa.me/966500000000',
        YOUTUBE: 'https://youtube.com/alsahala',
        TIKTOK: 'https://tiktok.com/@alsahala'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // معلومات الاتصال
    // ═══════════════════════════════════════════════════════════════════
    
    CONTACT: {
        EMAIL: 'info@alsahala.com',
        PHONE: '+966500000000',
        WHATSAPP: '+966500000000',
        ADDRESS: 'المملكة العربية السعودية'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // روابط الدفع
    // ═══════════════════════════════════════════════════════════════════
    
    PAYMENT_METHODS: [
        { id: 'mada', name: 'مدى', icon: 'card' },
        { id: 'visa', name: 'فيزا', icon: 'card' },
        { id: 'mastercard', name: 'ماستركارد', icon: 'card' },
        { id: 'applepay', name: 'أبل باي', icon: 'apple' },
        { id: 'stcpay', name: 'STC Pay', icon: 'phone' },
        { id: 'cod', name: 'الدفع عند الاستلام', icon: 'cash' }
    ],
    
    // ═══════════════════════════════════════════════════════════════════
    // شركات الشحن
    // ═══════════════════════════════════════════════════════════════════
    
    SHIPPING_METHODS: [
        { id: 'aramex', name: 'أرامكس', icon: 'truck', days: '3-5 أيام عمل' },
        { id: 'smsa', name: 'سمسا إكسبريس', icon: 'truck', days: '2-4 أيام عمل' },
        { id: 'dhl', name: 'DHL', icon: 'truck', days: '2-3 أيام عمل' },
        { id: 'free', name: 'توصيل مجاني', icon: 'gift', days: '5-7 أيام عمل' }
    ],
    
    // ═══════════════════════════════════════════════════════════════════
    // إعدادات التذييل
    // ═══════════════════════════════════════════════════════════════════
    
    FOOTER_LINKS: {
        ABOUT: [
            { title: 'من نحن', url: '/about' },
            { title: 'مهمتنا', url: '/mission' },
            { title: 'رؤيتنا', url: '/vision' },
            { title: 'الوظائف', url: '/careers' }
        ],
        CUSTOMER_SERVICE: [
            { title: 'مركز المساعدة', url: '/help' },
            { title: 'سياسة الخصوصية', url: '/privacy' },
            { title: 'الشروط والأحكام', url: '/terms' },
            { title: 'سياسة الإرجاع', url: '/returns' }
        ],
        SHOPPING: [
            { title: 'المتجر', url: '/shop' },
            { title: 'الفئات', url: '/categories' },
            { title: 'العروض', url: '/deals' },
            { title: 'الماركات', url: '/brands' }
        ],
        ACCOUNT: [
            { title: 'حسابي', url: '/account' },
            { title: 'طلباتي', url: '/orders' },
            { title: 'قائمة الأمنيات', url: '/wishlist' },
            { title: 'تسجيل الدخول', url: '/login' }
        ]
    }
};

// تصدير الثوابت
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
