/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  إعدادات API - Al-Sahala Enterprise                                 ║
 * ║  API Configuration - نقاط النهاية وإعدادات الطلبات                  ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const API_ENDPOINTS = {
    // ═══════════════════════════════════════════════════════════════════
    // المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    PRODUCTS: {
        LIST: '/products',
        DETAILS: (id) => `/products/${id}`,
        CATEGORIES: '/products/categories',
        FEATURED: '/products/featured',
        NEW_ARRIVALS: '/products/new-arrivals',
        BEST_SELLERS: '/products/best-sellers',
        ON_SALE: '/products/on-sale',
        SEARCH: '/products/search',
        REVIEWS: (id) => `/products/${id}/reviews`,
        RELATED: (id) => `/products/${id}/related`,
        OPTIONS: (id) => `/products/${id}/options`,
        INVENTORY: (id) => `/products/${id}/inventory`
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الفئات
    // ═══════════════════════════════════════════════════════════════════
    
    CATEGORIES: {
        LIST: '/categories',
        DETAILS: (id) => `/categories/${id}`,
        TREE: '/categories/tree',
        FEATURED: '/categories/featured',
        PRODUCTS: (id) => `/categories/${id}/products`,
        BANNERS: '/categories/banners'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // سلة التسوق
    // ═══════════════════════════════════════════════════════════════════
    
    CART: {
        GET: '/cart',
        ADD: '/cart/items',
        UPDATE: (itemId) => `/cart/items/${itemId}`,
        REMOVE: (itemId) => `/cart/items/${itemId}`,
        CLEAR: '/cart/clear',
        COUPON: '/cart/coupon',
        SHIPPING: '/cart/shipping',
        VALIDATE: '/cart/validate'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // المستخدم
    // ═══════════════════════════════════════════════════════════════════
    
    USER: {
        PROFILE: '/user/profile',
        UPDATE: '/user/profile',
        ADDRESSES: '/user/addresses',
        ADDRESS: (id) => `/user/addresses/${id}`,
        ORDERS: '/user/orders',
        ORDER: (id) => `/user/orders/${id}`,
        WISHLIST: '/user/wishlist',
        NOTIFICATIONS: '/user/notifications',
        PREFERENCES: '/user/preferences'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // المصادقة
    // ═══════════════════════════════════════════════════════════════════
    
    AUTH: {
        LOGIN: '/auth/login',
        REGISTER: '/auth/register',
        LOGOUT: '/auth/logout',
        FORGOT_PASSWORD: '/auth/forgot-password',
        RESET_PASSWORD: '/auth/reset-password',
        REFRESH_TOKEN: '/auth/refresh-token',
        VERIFY_EMAIL: '/auth/verify-email',
        RESEND_VERIFICATION: '/auth/resend-verification'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الدفع
    // ═══════════════════════════════════════════════════════════════════
    
    CHECKOUT: {
        CREATE: '/checkout',
        PAYMENT_METHODS: '/checkout/payment-methods',
        PROCESS: (id) => `/checkout/${id}/process`,
        COMPLETE: (id) => `/checkout/${id}/complete`,
        CANCEL: (id) => `/checkout/${id}/cancel`
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // البحث
    // ═══════════════════════════════════════════════════════════════════
    
    SEARCH: {
        QUERY: '/search',
        SUGGESTIONS: '/search/suggestions',
        TRENDING: '/search/trending',
        FILTERS: '/search/filters',
        HISTORY: '/search/history'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // المراجعات والتقييمات
    // ═══════════════════════════════════════════════════════════════════
    
    REVIEWS: {
        LIST: '/reviews',
        CREATE: '/reviews',
        UPDATE: (id) => `/reviews/${id}`,
        DELETE: (id) => `/reviews/${id}`,
        HELPFUL: (id) => `/reviews/${id}/helpful`,
        REPORT: (id) => `/reviews/${id}/report`
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الكوبونات والخصومات
    // ═══════════════════════════════════════════════════════════════════
    
    COUPONS: {
        VALIDATE: '/coupons/validate',
        APPLY: '/coupons/apply',
        REMOVE: '/coupons/remove',
        LIST: '/coupons',
        MY_COUPONS: '/coupons/my-coupons'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الإشعارات
    // ═══════════════════════════════════════════════════════════════════
    
    NOTIFICATIONS: {
        LIST: '/notifications',
        MARK_READ: (id) => `/notifications/${id}/read`,
        MARK_ALL_READ: '/notifications/read-all',
        SETTINGS: '/notifications/settings'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الإحصائيات
    // ═══════════════════════════════════════════════════════════════════
    
    ANALYTICS: {
        DASHBOARD: '/analytics/dashboard',
        ORDERS: '/analytics/orders',
        PRODUCTS: '/analytics/products',
        USERS: '/analytics/users',
        REVENUE: '/analytics/revenue'
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // الإعدادات العامة
    // ═══════════════════════════════════════════════════════════════════
    
    SETTINGS: {
        GENERAL: '/settings/general',
        PAYMENT: '/settings/payment',
        SHIPPING: '/settings/shipping',
        TAXES: '/settings/taxes'
    }
};

// ═══════════════════════════════════════════════════════════════════════
// معالج API
// ═══════════════════════════════════════════════════════════════════════

class APIHandler {
    constructor() {
        this.baseUrl = CONFIG.API_BASE_URL;
        this.timeout = CONFIG.API_TIMEOUT;
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
    }
    
    // الحصول على عنوان URL الكامل
    getFullUrl(endpoint) {
        return `${this.baseUrl}${endpoint}`;
    }
    
    // إنشاء عنوان URL مع المعلمات
    buildUrl(endpoint, params = {}) {
        const url = new URL(this.getFullUrl(endpoint), window.location.origin);
        Object.keys(params).forEach(key => {
            if (params[key] !== null && params[key] !== undefined) {
                url.searchParams.append(key, params[key]);
            }
        });
        return url.toString();
    }
    
    // إنشاء رأس المصادقة
    getAuthHeaders() {
        const token = localStorage.getItem(CONFIG.SECURITY.TOKEN_KEY);
        return token ? { ...this.defaultHeaders, 'Authorization': `Bearer ${token}` } : this.defaultHeaders;
    }
    
    // طلب GET
    async get(endpoint, params = {}) {
        const url = this.buildUrl(endpoint, params);
        const response = await fetch(url, {
            method: 'GET',
            headers: this.getAuthHeaders(),
            timeout: this.timeout
        });
        return this.handleResponse(response);
    }
    
    // طلب POST
    async post(endpoint, data = {}) {
        const response = await fetch(this.getFullUrl(endpoint), {
            method: 'POST',
            headers: this.getAuthHeaders(),
            body: JSON.stringify(data),
            timeout: this.timeout
        });
        return this.handleResponse(response);
    }
    
    // طلب PUT
    async put(endpoint, data = {}) {
        const response = await fetch(this.getFullUrl(endpoint), {
            method: 'PUT',
            headers: this.getAuthHeaders(),
            body: JSON.stringify(data),
            timeout: this.timeout
        });
        return this.handleResponse(response);
    }
    
    // طلب PATCH
    async patch(endpoint, data = {}) {
        const response = await fetch(this.getFullUrl(endpoint), {
            method: 'PATCH',
            headers: this.getAuthHeaders(),
            body: JSON.stringify(data),
            timeout: this.timeout
        });
        return this.handleResponse(response);
    }
    
    // طلب DELETE
    async delete(endpoint) {
        const response = await fetch(this.getFullUrl(endpoint), {
            method: 'DELETE',
            headers: this.getAuthHeaders(),
            timeout: this.timeout
        });
        return this.handleResponse(response);
    }
    
    // معالجة الاستجابة
    async handleResponse(response) {
        if (!response.ok) {
            const error = await response.json().catch(() => ({ message: 'حدث خطأ في الطلب' }));
            throw new Error(error.message || `خطأ في الطلب: ${response.status}`);
        }
        return response.json().catch(() => ({ success: true }));
    }
    
    // طلب مع نموذج بيانات
    async postFormData(endpoint, formData) {
        const response = await fetch(this.getFullUrl(endpoint), {
            method: 'POST',
            headers: {
                'Authorization': this.getAuthHeaders()['Authorization']
            },
            body: formData,
            timeout: this.timeout
        });
        return this.handleResponse(response);
    }
}

// ═══════════════════════════════════════════════════════════════════════
// مدير التخزين المؤقت
// ═══════════════════════════════════════════════════════════════════════

class CacheManager {
    constructor() {
        this.storage = window.localStorage;
    }
    
    // الحصول على مفتاح التخزين المؤقت
    getKey(key, params = {}) {
        const paramString = Object.keys(params).sort().map(k => `${k}=${params[k]}`).join('&');
        return `${key}_${paramString}`;
    }
    
    // الحصول على البيانات المخزنة مؤقتاً
    get(key, params = {}) {
        try {
            const cacheKey = this.getKey(key, params);
            const cached = this.storage.getItem(cacheKey);
            if (!cached) return null;
            
            const { data, timestamp } = JSON.parse(cached);
            const duration = CONFIG.CACHE_DURATION[key] || CONFIG.CACHE_DURATION.PRODUCTS;
            
            if (Date.now() - timestamp > duration) {
                this.remove(key, params);
                return null;
            }
            
            return data;
        } catch (e) {
            console.error('خطأ في قراءة التخزين المؤقت:', e);
            return null;
        }
    }
    
    // تخزين البيانات مؤقتاً
    set(key, data, params = {}) {
        try {
            const cacheKey = this.getKey(key, params);
            const cacheData = {
                data,
                timestamp: Date.now()
            };
            this.storage.setItem(cacheKey, JSON.stringify(cacheData));
        } catch (e) {
            console.error('خطأ في التخزين المؤقت:', e);
        }
    }
    
    // إزالة البيانات المخزنة مؤقتاً
    remove(key, params = {}) {
        try {
            const cacheKey = this.getKey(key, params);
            this.storage.removeItem(cacheKey);
        } catch (e) {
            console.error('خطأ في حذف التخزين المؤقت:', e);
        }
    }
    
    // مسح جميع البيانات المخزنة مؤقتاً
    clear(key) {
        try {
            const keys = Object.keys(this.storage);
            keys.forEach(k => {
                if (k.startsWith(key)) {
                    this.storage.removeItem(k);
                }
            });
        } catch (e) {
            console.error('خطأ في مسح التخزين المؤقت:', e);
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
// إنشاء مثيلات الإدارة
// ═══════════════════════════════════════════════════════════════════════

const api = new APIHandler();
const cache = new CacheManager();

// تصدير الوحدات
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { API_ENDPOINTS, APIHandler, CacheManager, api, cache };
}
