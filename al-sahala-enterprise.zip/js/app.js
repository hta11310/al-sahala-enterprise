/**
 * ═══════════════════════════════════════════════════════════════════════
 * ║  التطبيق الرئيسي - Al-Sahala Enterprise                             ║
 * ║  Main Application - تهيئة جميع الوحدات والتطبيق                      ║
 * ═══════════════════════════════════════════════════════════════════════
 */

const App = {
    // ═══════════════════════════════════════════════════════════════════
    // التهيئة
    // ═══════════════════════════════════════════════════════════════════
    
    init() {
        console.log('🚀 تهيئة منصة ومتجر السهالة...');
        
        // تهيئة الأنظمة الأساسية
        this.initCoreSystems();
        
        // تهيئة واجهة المستخدم
        this.initUI();
        
        // ت-commerce
        this.initCommerce();
        
        // تهيئة البحث
        this.initSearch();
        
        // تهيئة المكونات الإضافية
        this.initComponents();
        
        console.log('✅ تم تهيئة المنصة بنجاح');
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة الأنظمة الأساسية
    // ═══════════════════════════════════════════════════════════════════
    
    initCoreSystems() {
        // تهيئة نظام الترجمة واللغات
        if (typeof I18N !== 'undefined') {
            I18N.init();
        }
        
        // تهيئة المديرين
        if (typeof CartManager !== 'undefined') {
            CartManager.init();
        }
        
        if (typeof WishlistManager !== 'undefined') {
            WishlistManager.init();
        }
        
        if (typeof ProductManager !== 'undefined') {
            ProductManager.init();
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة واجهة المستخدم
    // ═══════════════════════════════════════════════════════════════════
    
    initUI() {
        if (typeof UIManager !== 'undefined') {
            UIManager.init();
        }
        
        // تهيئة القائمة المنسدلة
        this.initDropdowns();
        
        // تهيئة التبديل بين اللغات
        this.initLanguageSwitcher();
        
        // تهيئة تبويبات المنتج
        this.initProductTabs();
        
        // تهيئة الشرائح
        this.initSliders();
        
        // تهيئة الأكورديون
        this.initAccordions();
        
        // تهيئة العدادات التنازلية
        this.initCountdowns();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة التجارة الإلكترونية
    // ═══════════════════════════════════════════════════════════════════
    
    initCommerce() {
        // عرض المنتجات المميزة في الصفحة الرئيسية
        this.renderFeaturedProducts();
        
        // عرض المنتجات الجديدة
        this.renderNewArrivals();
        
        // عرض الفئات
        this.renderCategoryCards();
        
        // عرض البانرات
        this.renderHeroBanners();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة البحث
    // ═══════════════════════════════════════════════════════════════════
    
    initSearch() {
        const searchInput = document.getElementById('search-input');
        const searchForm = document.getElementById('search-form');
        
        if (searchInput) {
            // البحث عند الكتابة
            let debounceTimer;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    const query = e.target.value;
                    if (query.length >= 2) {
                        this.performSearch(query);
                    }
                }, 300);
            });
            
            // البحث عند الضغط على Enter
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const query = e.target.value;
                    if (query.length >= 2) {
                        this.performSearch(query, true);
                    }
                }
            });
        }
        
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const query = searchInput?.value || '';
                if (query.length >= 2) {
                    this.performSearch(query, true);
                }
            });
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تنفيذ البحث
    // ═══════════════════════════════════════════════════════════════════
    
    performSearch(query, redirect = false) {
        // حفظ في عمليات البحث الأخيرة
        this.saveRecentSearch(query);
        
        if (typeof ProductManager !== 'undefined') {
            ProductManager.searchProducts(query);
        }
        
        if (redirect) {
            window.location.href = `shop.html?search=${encodeURIComponent(query)}`;
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // حفظ عمليات البحث الأخيرة
    // ═══════════════════════════════════════════════════════════════════
    
    saveRecentSearch(query) {
        let searches = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEYS.RECENT_SEARCHES) || '[]');
        
        // إزالة البحث إذا كان موجوداً
        searches = searches.filter(s => s !== query);
        
        // إضافة البحث في البداية
        searches.unshift(query);
        
        // الاحتفاظ بآخر 10 عمليات بحث
        searches = searches.slice(0, CONFIG.MAX_RECENT_SEARCHES);
        
        localStorage.setItem(CONFIG.STORAGE_KEYS.RECENT_SEARCHES, JSON.stringify(searches));
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة المكونات الإضافية
    // ═══════════════════════════════════════════════════════════════════
    
    initComponents() {
        // تهيئة منتقي الألوان
        this.initColorPickers();
        
        // تهيئة منتقي الأحجام
        this.initSizePickers();
        
        // تهيئة مؤشرات التقييم
        this.initRatingInputs();
        
        // تهيئة تحميل المزيد
        this.initLoadMore();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة القوائم المنسدلة
    // ═══════════════════════════════════════════════════════════════════
    
    initDropdowns() {
        document.addEventListener('click', (e) => {
            const dropdown = e.target.closest('[data-dropdown]');
            
            if (dropdown) {
                e.preventDefault();
                const isActive = dropdown.classList.contains('active');
                
                // إغلاق جميع القوائم المنسدلة
                document.querySelectorAll('[data-dropdown].active').forEach(d => {
                    d.classList.remove('active');
                });
                
                // فتح القائمة المنسدلة المحددة
                if (!isActive) {
                    dropdown.classList.add('active');
                }
            } else {
                // إغلاق القائمة المنسدلة عند النقر خارجها
                document.querySelectorAll('[data-dropdown].active').forEach(d => {
                    d.classList.remove('active');
                });
            }
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة مفتاح اللغة
    // ═══════════════════════════════════════════════════════════════════
    
    initLanguageSwitcher() {
        document.querySelectorAll('[data-language]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const lang = btn.dataset.language;
                if (typeof I18N !== 'undefined') {
                    I18N.setLanguage(lang);
                }
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة تبويبات المنتج
    // ═══════════════════════════════════════════════════════════════════
    
    initProductTabs() {
        document.querySelectorAll('.tabs').forEach(tabsContainer => {
            const tabButtons = tabsContainer.querySelectorAll('.tab-btn');
            const tabPanels = tabsContainer.querySelectorAll('.tab-panel');
            
            tabButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    const targetPanel = btn.dataset.tab;
                    
                    // إزالة الفئة النشطة من جميع الأزرار واللوحات
                    tabButtons.forEach(b => b.classList.remove('active'));
                    tabPanels.forEach(p => p.classList.remove('active'));
                    
                    // إضافة الفئة النشطة للزر واللوحة المحددة
                    btn.classList.add('active');
                    const target = tabsContainer.querySelector(`#${targetPanel}`);
                    if (target) {
                        target.classList.add('active');
                    }
                });
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة الشرائح
    // ═══════════════════════════════════════════════════════════════════
    
    initSliders() {
        // شريحة الرئيسية
        this.initHeroSlider();
        
        // شرائح المنتجات
        this.initProductSlider();
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة شريحة الرئيسية
    // ═══════════════════════════════════════════════════════════════════
    
    initHeroSlider() {
        const slider = document.getElementById('hero-slider');
        if (!slider) return;
        
        const slides = slider.querySelectorAll('.hero-slide');
        const prevBtn = slider.querySelector('.slider-prev');
        const nextBtn = slider.querySelector('.slider-next');
        const dots = slider.querySelectorAll('.slider-dot');
        
        if (slides.length === 0) return;
        
        let currentSlide = 0;
        const totalSlides = slides.length;
        
        const goToSlide = (index) => {
            slides.forEach((slide, i) => {
                slide.classList.toggle('active', i === index);
            });
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
            currentSlide = index;
        };
        
        const nextSlide = () => {
            const next = (currentSlide + 1) % totalSlides;
            goToSlide(next);
        };
        
        const prevSlide = () => {
            const prev = (currentSlide - 1 + totalSlides) % totalSlides;
            goToSlide(prev);
        };
        
        // إضافة المستمعين للأزرار
        if (nextBtn) {
            nextBtn.addEventListener('click', nextSlide);
        }
        
        if (prevBtn) {
            prevBtn.addEventListener('click', prevSlide);
        }
        
        // إضافة المستمعين للنقاط
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => goToSlide(index));
        });
        
        // التبديل التلقائي
        let autoSlide = setInterval(nextSlide, 5000);
        
        // إيقاف التبديل التلقائي عند التفاعل
        slider.addEventListener('mouseenter', () => {
            clearInterval(autoSlide);
        });
        
        slider.addEventListener('mouseleave', () => {
            autoSlide = setInterval(nextSlide, 5000);
        });
        
        // التبديل باللمسم
        if ('ontouchstart' in window) {
            let touchStartX = 0;
            let touchEndX = 0;
            
            slider.addEventListener('touchstart', (e) => {
                touchStartX = e.changedTouches[0].screenX;
            });
            
            slider.addEventListener('touchend', (e) => {
                touchEndX = e.changedTouches[0].screenX;
                if (touchStartX - touchEndX > 50) {
                    nextSlide();
                } else if (touchEndX - touchStartX > 50) {
                    prevSlide();
                }
            });
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة شرائح المنتجات
    // ═══════════════════════════════════════════════════════════════════
    
    initProductSlider() {
        const sliders = document.querySelectorAll('.products-slider');
        
        sliders.forEach(slider => {
            const container = slider.querySelector('.products-slider-container');
            const prevBtn = slider.querySelector('.slider-prev');
            const nextBtn = slider.querySelector('.slider-next');
            
            if (!container || !prevBtn || !nextBtn) return;
            
            let scrollPosition = 0;
            const scrollAmount = 280; // عرض البطاقة + gap
            
            const scrollNext = () => {
                const maxScroll = container.scrollWidth - container.clientWidth;
                if (scrollPosition < maxScroll) {
                    scrollPosition = Math.min(scrollPosition + scrollAmount, maxScroll);
                    container.scrollTo({ left: scrollPosition, behavior: 'smooth' });
                }
            };
            
            const scrollPrev = () => {
                if (scrollPosition > 0) {
                    scrollPosition = Math.max(scrollPosition - scrollAmount, 0);
                    container.scrollTo({ left: scrollPosition, behavior: 'smooth' });
                }
            };
            
            nextBtn.addEventListener('click', scrollNext);
            prevBtn.addEventListener('click', scrollPrev);
            
            // تحديث حالة الأزرار
            container.addEventListener('scroll', () => {
                const maxScroll = container.scrollWidth - container.clientWidth;
                prevBtn.disabled = container.scrollLeft <= 0;
                nextBtn.disabled = container.scrollLeft >= maxScroll;
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة الأكورديون
    // ═══════════════════════════════════════════════════════════════════
    
    initAccordions() {
        document.querySelectorAll('.accordion-header').forEach(header => {
            header.addEventListener('click', () => {
                const accordion = header.closest('.accordion-item');
                const isActive = accordion.classList.contains('active');
                
                // إغلاق جميع العناصر
                accordion.parentElement.querySelectorAll('.accordion-item').forEach(item => {
                    item.classList.remove('active');
                });
                
                // فتح العنصر المحدد
                if (!isActive) {
                    accordion.classList.add('active');
                }
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة العدادات التنازلية
    // ═══════════════════════════════════════════════════════════════════
    
    initCountdowns() {
        document.querySelectorAll('[data-countdown]').forEach(el => {
            const endDate = new Date(el.dataset.countdown).getTime();
            
            const updateCountdown = () => {
                const now = new Date().getTime();
                const distance = endDate - now;
                
                if (distance < 0) {
                    el.innerHTML = 'انتهى العرض!';
                    return;
                }
                
                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);
                
                el.innerHTML = `
                    <span class="countdown-item">
                        <span class="countdown-value">${String(days).padStart(2, '0')}</span>
                        <span class="countdown-label">${I18N.t('days.saturday').substring(0, 3)}</span>
                    </span>
                    <span class="countdown-separator">:</span>
                    <span class="countdown-item">
                        <span class="countdown-value">${String(hours).padStart(2, '0')}</span>
                        <span class="countdown-label">س</span>
                    </span>
                    <span class="countdown-separator">:</span>
                    <span class="countdown-item">
                        <span class="countdown-value">${String(minutes).padStart(2, '0')}</span>
                        <span class="countdown-label">د</span>
                    </span>
                    <span class="countdown-separator">:</span>
                    <span class="countdown-item">
                        <span class="countdown-value">${String(seconds).padStart(2, '0')}</span>
                        <span class="countdown-label">ث</span>
                    </span>
                `;
            };
            
            updateCountdown();
            setInterval(updateCountdown, 1000);
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة منتقي الألوان
    // ═══════════════════════════════════════════════════════════════════
    
    initColorPickers() {
        document.querySelectorAll('.variant-swatch, .color-swatch').forEach(swatch => {
            swatch.addEventListener('click', () => {
                const parent = swatch.parentElement;
                parent.querySelectorAll('.variant-swatch, .color-swatch').forEach(s => {
                    s.classList.remove('active');
                });
                swatch.classList.add('active');
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة منتقي الأحجام
    // ═══════════════════════════════════════════════════════════════════
    
    initSizePickers() {
        document.querySelectorAll('.size-option').forEach(option => {
            option.addEventListener('click', () => {
                const parent = option.parentElement;
                parent.querySelectorAll('.size-option').forEach(o => {
                    o.classList.remove('active');
                });
                option.classList.add('active');
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة مؤشرات التقييم
    // ═══════════════════════════════════════════════════════════════════
    
    initRatingInputs() {
        document.querySelectorAll('.rating-input').forEach(container => {
            const stars = container.querySelectorAll('.rating-star');
            
            stars.forEach((star, index) => {
                star.addEventListener('click', () => {
                    const rating = index + 1;
                    const input = container.querySelector('input[type="hidden"]');
                    
                    stars.forEach((s, i) => {
                        if (i < rating) {
                            s.classList.add('active');
                            s.querySelector('svg').style.fill = 'currentColor';
                        } else {
                            s.classList.remove('active');
                            s.querySelector('svg').style.fill = 'transparent';
                        }
                    });
                    
                    if (input) {
                        input.value = rating;
                    }
                });
                
                star.addEventListener('mouseenter', () => {
                    const index = Array.from(stars).indexOf(star);
                    stars.forEach((s, i) => {
                        if (i <= index) {
                            s.style.opacity = '1';
                        } else {
                            s.style.opacity = '0.5';
                        }
                    });
                });
                
                star.addEventListener('mouseleave', () => {
                    stars.forEach(s => {
                        if (s.classList.contains('active')) {
                            s.style.opacity = '1';
                        } else {
                            s.style.opacity = '1';
                        }
                    });
                });
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // تهيئة تحميل المزيد
    // ═══════════════════════════════════════════════════════════════════
    
    initLoadMore() {
        document.querySelectorAll('[data-load-more]').forEach(btn => {
            btn.addEventListener('click', () => {
                const target = btn.dataset.loadMore;
                const container = document.getElementById(target);
                
                if (container) {
                    btn.classList.add('loading');
                    btn.disabled = true;
                    
                    // محاكاة تحميل المزيد
                    setTimeout(() => {
                        btn.classList.remove('loading');
                        btn.disabled = false;
                        btn.style.display = 'none';
                    }, 1000);
                }
            });
        });
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض المنتجات المميزة
    // ═══════════════════════════════════════════════════════════════════
    
    renderFeaturedProducts() {
        const container = document.getElementById('featured-products');
        if (!container || typeof ProductManager === 'undefined') return;
        
        const products = ProductManager.getFeaturedProducts().slice(0, 4);
        
        if (products.length === 0) return;
        
        let html = '<div class="products-row">';
        products.forEach(product => {
            html += ProductManager.getProductCard(product);
        });
        html += '</div>';
        
        container.innerHTML = html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض المنتجات الجديدة
    // ═══════════════════════════════════════════════════════════════════
    
    renderNewArrivals() {
        const container = document.getElementById('new-arrivals');
        if (!container || typeof ProductManager === 'undefined') return;
        
        const products = ProductManager.getNewArrivals();
        
        if (products.length === 0) return;
        
        let html = '<div class="products-row">';
        products.forEach(product => {
            html += ProductManager.getProductCard(product);
        });
        html += '</div>';
        
        container.innerHTML = html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض بطاقات الفئات
    // ═══════════════════════════════════════════════════════════════════
    
    renderCategoryCards() {
        const container = document.getElementById('category-cards');
        if (!container || typeof ProductManager === 'undefined') return;
        
        const categories = ProductManager.mockCategories.filter(c => c.id !== 'all').slice(0, 6);
        
        let html = '<div class="grid-container grid-3">';
        categories.forEach(category => {
            html += `
                <a href="shop.html?category=${category.id}" class="category-card">
                    <img src="https://picsum.photos/400/300?random=${category.id}" 
                         alt="${category.name}" 
                         class="category-card-bg"
                         loading="lazy">
                    <div class="category-card-overlay"></div>
                    <div class="category-card-content">
                        <h3 class="category-card-title">${category.name}</h3>
                        <span class="category-card-count">${category.count} منتج</span>
                    </div>
                </a>
            `;
        });
        html += '</div>';
        
        container.innerHTML = html;
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // عرض بانرات الرئيسية
    // ═══════════════════════════════════════════════════════════════════
    
    renderHeroBanners() {
        const container = document.getElementById('hero-banners');
        if (!container) return;
        
        container.innerHTML = `
            <div class="grid-container grid-2">
                <a href="shop.html?category=electronics" class="banner-card">
                    <img src="https://picsum.photos/600/400?random=electronics" alt="إلكترونيات" class="banner-card-bg">
                    <div class="banner-card-content">
                        <span class="banner-card-tag">خصم 20%</span>
                        <h3 class="banner-card-title">إلكترونيات رائدة</h3>
                        <p class="banner-card-text">أحدث الأجهزة التقنية بأفضل الأسعار</p>
                        <span class="btn btn-secondary">تسوق الآن</span>
                    </div>
                </a>
                <a href="shop.html?category=clothing" class="banner-card">
                    <img src="https://picsum.photos/600/400?random=clothing" alt="أزياء" class="banner-card-bg">
                    <div class="banner-card-content">
                        <span class="banner-card-tag">موضة 2024</span>
                        <h3 class="banner-card-title">أزياء عصرية</h3>
                        <p class="banner-card-text">تشكيلة واسعة من الأزياء للرجال والنساء</p>
                        <span class="btn btn-secondary">تسوق الآن</span>
                    </div>
                </a>
            </div>
        `;
    }
};

// ═══════════════════════════════════════════════════════════════════════
// دوال مساعدة عامة
// ═══════════════════════════════════════════════════════════════════════

// تنسيق الرقم
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// تنسيق التاريخ
function formatDate(date) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(date).toLocaleDateString('ar-SA', options);
}

// إنشاء معرف فريد
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// تأخير
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// تكرار
function throttle(func, limit) {
    let inThrottle;
    return function executedFunction(...args) {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ═══════════════════════════════════════════════════════════════════════
// تهيئة التطبيق عند تحميل الصفحة
// ═══════════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

// تصدير التطبيق
if (typeof module !== 'undefined' && module.exports) {
    module.exports = App;
}
