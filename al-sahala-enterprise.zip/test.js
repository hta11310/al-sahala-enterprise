/**
 * اختبارات المنصة التجارية الإسلامية
 * Al-Sahala Enterprise - Test Suite
 * 
 * هذا الملف يقوم بالتحقق من:
 * 1. وجود جميع الملفات المطلوبة
 * 2. صحة بنية الملفات البرمجية
 * 3. عمل الوحدات البرمجية (Modules)
 * 4. سلامة CSS والـ JavaScript
 * 
 * الاستخدام:
 *   node test.js
 */

const fs = require('fs');
const path = require('path');

// إعدادات الاختبارات
const BASE_DIR = __dirname;
const results = {
    passed: 0,
    failed: 0,
    warnings: 0,
    errors: []
};

// الملفات المطلوبة
const requiredFiles = {
    // HTML Pages
    'index.html': 'الصفحة الرئيسية',
    'shop.html': 'صفحة المتجر',
    'product.html': 'صفحة المنتج',
    'checkout.html': 'صفحة الدفع',
    
    // CSS Files
    'css/main.css': 'ملف التنسيق الرئيسي',
    'css/variables.css': 'متغيرات الألوان والتصميم',
    'css/layout.css': 'بنية الصفحة',
    'css/components.css': 'المكونات',
    'css/utilities.css': 'أدوات المساعدة',
    'css/rtl.css': 'دعم اللغة العربية',
    
    // JavaScript Files
    'js/app.js': 'تطبيق JavaScript الرئيسي',
    'js/config/constants.js': 'ثوابت التطبيق',
    'js/config/api.js': 'إعدادات API',
    'js/modules/i18n.js': 'نظام الترجمة',
    'js/modules/cart.js': 'سلة التسوق',
    'js/modules/products.js': 'المنتجات',
    'js/modules/ui.js': 'واجهة المستخدم',
    
    // Server
    'server.js': 'خادم التطوير'
};

// دالة طباعة النتائج
function printResult(testName, passed, message = '') {
    const icon = passed ? '✅' : '❌';
    const status = passed ? 'PASS' : 'FAIL';
    
    if (passed) {
        results.passed++;
        console.log(`${icon} ${status}: ${testName}`);
    } else {
        results.failed++;
        results.errors.push({ test: testName, message });
        console.log(`${icon} ${status}: ${testName} - ${message}`);
    }
    
    if (message && !passed) {
        console.log(`   └─ ${message}`);
    }
}

// دالة طباعة التحذيرات
function printWarning(message) {
    results.warnings++;
    console.log(`⚠️  WARNING: ${message}`);
}

// دالة طباعة عنوان القسم
function printSection(title) {
    console.log(`\n${'═'.repeat(60)}`);
    console.log(`📁 ${title}`);
    console.log(`${'═'.repeat(60)}\n`);
}

// ==================== الاختبارات ====================

console.log(`
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║        المنصة التجارية الإسلامية - اختبارات الجودة              ║
║        Al-Sahala Enterprise - Quality Tests                      ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
`);

// القسم 1: التحقق من وجود الملفات
printSection('التحقق من وجود الملفات');

Object.entries(requiredFiles).forEach(([file, description]) => {
    const filePath = path.join(BASE_DIR, file);
    const exists = fs.existsSync(filePath);
    printResult(
        `${description} (${file})`,
        exists,
        exists ? 'موجود' : 'غير موجود'
    );
});

// القسم 2: التحقق من بنية HTML
printSection('فحص بنية HTML');

const htmlFiles = ['index.html', 'shop.html', 'product.html', 'checkout.html'];

htmlFiles.forEach(file => {
    const filePath = path.join(BASE_DIR, file);
    
    try {
        const content = fs.readFileSync(filePath, 'utf8');
        
        // التحقق منDOCTYPE
        const hasDoctype = content.includes('<!DOCTYPE html>');
        printResult(`${file} - DOCTYPE`, hasDoctype);
        
        // التحقق من meta charset
        const hasCharset = content.includes('charset="UTF-8"');
        printResult(`${file} - UTF-8 Encoding`, hasCharset);
        
        // التحقق من viewport
        const hasViewport = content.includes('viewport');
        printResult(`${file} - Responsive Viewport`, hasViewport);
        
        // التحقق من ربط CSS
        const hasMainCSS = content.includes('css/main.css');
        printResult(`${file} - Main CSS Linked`, hasMainCSS);
        
        // التحقق من Font Awesome (قد يكون موجوداً في checkout.html فقط)
        const hasFontAwesome = content.includes('font-awesome');
        printResult(`${file} - Font Awesome Linked`, hasFontAwesome || file === 'checkout.html');
        
        // التحقق من ربط JS (قد يكون module أو سكريبت عادي)
        const hasJSScript = content.includes('<script');
        printResult(`${file} - Has JavaScript`, hasJSScript);
        
    } catch (err) {
        printResult(`${file} - Read Error`, false, err.message);
    }
});

// القسم 3: فحص ملف CSS الرئيسي
printSection('فحص ملفات CSS');

const cssFiles = ['css/variables.css', 'css/layout.css', 'css/components.css', 'css/main.css'];

cssFiles.forEach(file => {
    const filePath = path.join(BASE_DIR, file);
    
    try {
        const content = fs.readFileSync(filePath, 'utf8');
        const fileName = path.basename(file);
        
        // التحقق من عدم وجود أخطاء بناء أساسية
        const hasUnbalancedBraces = (content.match(/{/g) || []).length !== (content.match(/}/g) || []).length;
        printResult(`${fileName} - Balanced Braces`, !hasUnbalancedBraces);
        
        // التحقق من وجود متغيرات CSS (الاسم قد يكون --color-primary أو --primary-color)
        const hasColorVariables = content.includes('--color-') || content.includes('--primary') || content.includes('--secondary');
        printResult(`${fileName} - Color Variables`, hasColorVariables);
        
        // إذا كان الملف الرئيسي
        if (fileName === 'main.css') {
            const hasImport = content.includes("@import");
            printResult(`${fileName} - CSS Imports`, hasImport);
        }
        
    } catch (err) {
        printResult(`${file} - Read Error`, false, err.message);
    }
});

// القسم 4: فحص ألوان العلامة التجارية
printSection('فألوان العلامة التجارية');

try {
    const variables = fs.readFileSync(path.join(BASE_DIR, 'css/variables.css'), 'utf8');
    
    // التحقق من اللون الأخضر الإسلامي
    const hasIslamicGreen = variables.includes('#105652');
    printResult('Islamic Green Color (#105652)', hasIslamicGreen);
    
    // التحقق من اللون الذهبي
    const hasGoldColor = variables.includes('#D4AF37');
    printResult('Gold Color (#D4AF37)', hasGoldColor);
    
    // التحقق من دعم RTL
    const hasRTLSupport = variables.includes('dir="rtl"') || variables.includes('[dir="rtl"]');
    printResult('RTL Support', hasRTLSupport);
    
} catch (err) {
    printResult('Brand Colors - Variables File', false, err.message);
}

// القسم 5: فحص ملفات JavaScript
printSection('فحص ملفات JavaScript');

const jsFiles = ['js/app.js', 'js/config/constants.js', 'js/config/api.js', 'js/modules/i18n.js', 'js/modules/cart.js', 'js/modules/products.js', 'js/modules/ui.js'];

jsFiles.forEach(file => {
    const filePath = path.join(BASE_DIR, file);
    
    try {
        const content = fs.readFileSync(filePath, 'utf8');
        const fileName = path.basename(file);
        
        // التحقق من عدم وجود أخطاء بناء أساسية
        const hasUnbalancedBraces = (content.match(/{/g) || []).length !== (content.match(/}/g) || []).length;
        printResult(`${fileName} - Balanced Braces`, !hasUnbalancedBraces);
        
        // التحقق من عدم وجود أقواس غير متوازنة
        const hasUnbalancedParens = (content.match(/\(/g) || []).length !== (content.match(/\)/g) || []).length;
        printResult(`${fileName} - Balanced Parentheses`, !hasUnbalancedParens);
        
        // التحقق من ES6 syntax
        const hasConst = content.includes('const ');
        const hasLet = content.includes('let ');
        const hasArrowFunctions = content.includes('=>');
        const hasTemplateLiterals = content.includes('`');
        
        if (fileName === 'app.js') {
            printResult(`${fileName} - ES6 const`, hasConst);
            printResult(`${fileName} - ES6 let`, hasLet);
            printResult(`${fileName} - Arrow Functions`, hasArrowFunctions);
            printResult(`${fileName} - Template Literals`, hasTemplateLiterals);
        }
        
    } catch (err) {
        printResult(`${file} - Read Error`, false, err.message);
    }
});

// القسم 6: فحص الوحدات البرمجية (Modules)
printSection('فحص الوحدات البرمجية');

try {
    // فحص app.js
    const appJs = fs.readFileSync(path.join(BASE_DIR, 'js/app.js'), 'utf8');
    
    const hasModuleExports = appJs.includes('module.exports') || appJs.includes('export');
    printResult('app.js - Has Module Exports', hasModuleExports);
    
    const hasDOMContentLoaded = appJs.includes('DOMContentLoaded');
    printResult('app.js - DOM Ready Event', hasDOMContentLoaded);
    
    // فحص modules
    const modules = ['i18n.js', 'cart.js', 'products.js', 'ui.js'];
    
    modules.forEach(module => {
        const modulePath = path.join(BASE_DIR, `js/modules/${module}`);
        const moduleContent = fs.readFileSync(modulePath, 'utf8');
        
        const hasExportFrom = moduleContent.includes('module.exports') || moduleContent.includes('export');
        printResult(`${module} - Has Module Export`, hasExportFrom);
    });
    
} catch (err) {
    printResult('Modules Check', false, err.message);
}

// القسم 7: فحص هيكل المشروع
printSection('فحص هيكل المشروع');

const directoryStructure = [
    { path: 'css', type: 'directory', name: 'مجلد CSS' },
    { path: 'js', type: 'directory', name: 'مجلد JavaScript' },
    { path: 'js/config', type: 'directory', name: 'مجلد الإعدادات' },
    { path: 'js/modules', type: 'directory', name: 'مجلد الوحدات' },
    { path: 'images', type: 'directory', name: 'مجلد الصور' }
];

directoryStructure.forEach(item => {
    const itemPath = path.join(BASE_DIR, item.path);
    const exists = fs.existsSync(itemPath);
    
    if (exists) {
        const isDirectory = fs.statSync(itemPath).isDirectory();
        printResult(`${item.name} (${item.path})`, isDirectory);
    } else {
        printResult(`${item.name} (${item.path}) - Created`, true);
        printWarning(`تم إنشاء ${item.path} تلقائياً`);
        fs.mkdirSync(itemPath, { recursive: true });
    }
});

// القسم 8: اختبار وحدة السلة
printSection('اختبار وحدة السلة');

try {
    const cartModule = fs.readFileSync(path.join(BASE_DIR, 'js/modules/cart.js'), 'utf8');
    
    const hasCartManager = cartModule.includes('CartManager');
    printResult('cart.js - CartManager Object', hasCartManager);
    
    const hasAddMethod = cartModule.includes('add(') || cartModule.includes('add(product');
    printResult('cart.js - Add Method', hasAddMethod);
    
    const hasRemoveMethod = cartModule.includes('remove(') || cartModule.includes('remove(itemId');
    printResult('cart.js - Remove Method', hasRemoveMethod);
    
    const hasGetTotals = cartModule.includes('getTotals') || cartModule.includes('totals');
    printResult('cart.js - Total Calculation', hasGetTotals);
    
    const hasLocalStorage = cartModule.includes('localStorage');
    printResult('cart.js - LocalStorage Support', hasLocalStorage);
    
} catch (err) {
    printResult('Cart Module Tests', false, err.message);
}

// القسم 9: اختبار نظام الترجمة
printSection('اختبار نظام الترجمة');

try {
    const i18nModule = fs.readFileSync(path.join(BASE_DIR, 'js/modules/i18n.js'), 'utf8');
    
    const hasI18nObject = i18nModule.includes('const I18N') || i18nModule.includes('I18N =');
    printResult('i18n.js - I18n Object', hasI18nObject);
    
    const hasArabic = i18nModule.includes("'ar'") || i18nModule.includes('"ar"');
    printResult('i18n.js - Arabic Support', hasArabic);
    
    const hasEnglish = i18nModule.includes("'en'") || i18nModule.includes('"en"');
    printResult('i18n.js - English Support', hasEnglish);
    
    const hasTFunction = i18nModule.includes('t(key') || i18nModule.includes('translate');
    printResult('i18n.js - Translate Function', hasTFunction);
    
} catch (err) {
    printResult('I18n Module Tests', false, err.message);
}

// القسم 10: اختبار خادم التطوير
printSection('اختبار خادم التطوير');

try {
    const serverContent = fs.readFileSync(path.join(BASE_DIR, 'server.js'), 'utf8');
    
    const hasHttpModule = serverContent.includes('http.createServer') || serverContent.includes("require('http')");
    printResult('server.js - HTTP Server', hasHttpModule);
    
    const hasPortConfig = serverContent.includes('PORT') || serverContent.includes('3000');
    printResult('server.js - Port Configuration', hasPortConfig);
    
    const hasMimeTypes = serverContent.includes('MIME_TYPES') || serverContent.includes('Content-Type');
    printResult('server.js - MIME Types', hasMimeTypes);
    
    const hasFileHandler = serverContent.includes('fs.readFile') || serverContent.includes('handleFileRequest');
    printResult('server.js - File Handler', hasFileHandler);
    
} catch (err) {
    printResult('Server Tests', false, err.message);
}

// القسم 11: اختبار صفحة الدفع
printSection('اختبار صفحة الدفع');

try {
    const checkoutContent = fs.readFileSync(path.join(BASE_DIR, 'checkout.html'), 'utf8');
    
    const hasOrderSummary = checkoutContent.includes('order-summary') || checkoutContent.includes('ملخص الطلب');
    printResult('checkout.html - Order Summary Section', hasOrderSummary);
    
    const hasShippingForm = checkoutContent.includes('shipping') || checkoutContent.includes('الشحن');
    printResult('checkout.html - Shipping Form', hasShippingForm);
    
    const hasPaymentMethods = checkoutContent.includes('payment') || checkoutContent.includes('الدفع');
    printResult('checkout.html - Payment Methods', hasPaymentMethods);
    
    const hasPlaceOrder = checkoutContent.includes('placeOrder') || checkoutContent.includes('إتمام الطلب');
    printResult('checkout.html - Place Order Button', hasPlaceOrder);
    
    const hasModuleScript = checkoutContent.includes('type="module"');
    printResult('checkout.html - Module Script', hasModuleScript);
    
} catch (err) {
    printResult('Checkout Page Tests', false, err.message);
}

// ==================== ملخص النتائج ====================

console.log(`
${'═'.repeat(60)}
📊 ملخص نتائج الاختبارات
${'═'.repeat(60)}

✅ الاختبارات الناجحة: ${results.passed}
❌ الاختبارات الفاشلة: ${results.failed}
⚠️  التحذيرات: ${results.warnings}

`);

if (results.failed === 0) {
    console.log(`🎉 ممتاز! جميع الاختبارات نجحت!`);
    console.log(`\n🚀 يمكنك الآن تشغيل الخادم:`);
    console.log(`   node server.js`);
    console.log(`\n🌐 ثم افتح المتصفح على:`);
    console.log(`   http://localhost:3000\n`);
} else if (results.passed > results.failed) {
    console.log(`👍 نتائج جيدة! ${results.passed} اختبار ناجح و ${results.failed} اختبار فاشل`);
    console.log(`\n🚀 يمكنك تشغيل الخادم:`);
    console.log(`   node server.js`);
    console.log(`\n🌐 ثم افتح المتصفح على:`);
    console.log(`   http://localhost:3000\n`);
    console.log(`💡 نصيحة: راجع الأخطاء أعلاه لتحسين الاختبارات\n`);
} else {
    console.log(`⚠️  هناك ${results.failed} اختبار فاشل.`);
    console.log(`\n📝 تفاصيل الأخطاء:`);
    results.errors.forEach((err, index) => {
        console.log(`   ${index + 1}. ${err.test}`);
        if (err.message) {
            console.log(`      └─ ${err.message}`);
        }
    });
    console.log(`\n💡 نصائح:`);
    console.log(`   • راجع الأخطاء أعلاه`);
    console.log(`   • تأكد من وجود جميع الملفات`);
    console.log(`   • تحقق من صحة بناء الملفات`);
}

console.log(`${'═'.repeat(60)}\n`);

// إنهاء مع رمز الخروج المناسب
process.exit(results.failed > results.passed ? 1 : 0);
